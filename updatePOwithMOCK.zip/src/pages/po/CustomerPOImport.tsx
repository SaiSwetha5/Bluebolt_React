import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import type { PoUploadApiResponse } from '../../interfaces/CustomerPoInterface';
import { CUSTOMER_PO_MOCK } from '../../mock/Customer_PO_MOCK';

 
// Service helper to call the upload API
async function uploadPoFileApi(file: File): Promise<PoUploadApiResponse> {
  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetch('/api/po/upload-intake', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Upload failed with status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.warn('Backend API call unreachable or error, falling back to mock response contract:', error);
    // Fallback Mock Payload exactly as requested
    return CUSTOMER_PO_MOCK;
  }
}

export default function CustomerPOIntake() {
  const navigate = useNavigate();
  const { intakePO, catalog = [] } = useData();

  const catalogOptions = [
    'FN4FC',
    'HP EliteBook 8 G1i 14 AI',
    'HP EliteBook 8 G1i 16 AI',
    'HP EliteBook Ultra G1i AI',
    'HP EliteBook X Flip G1i AI',
    'HP EliteDesk 8 G1i Mini',
    'HP ZBook Fury G1i 16 O2O',
    'HP ZBook Fury G1i 16, i7 265HX',
    'HP Z2 Tower G1i',
    'HP ZBook Fury G1i 16, i7 265HX (Ubuntu)',
    'HP Z6 G5 W52545'
  ];

  const emptyForm = {
    customerName: '',
    poNumber: '',
    supplier: '',
    shipment: 'Air Freight',
    customerEntity: '',
    entityCode: '',
    partNumber: '',
    catalog: '',
    units: '',
    perUnitCost: '',
    billingMethod: 'Monthly',
    country: '',
    state: '',
    city: '',
    address1: '',
    pincode: ''
  };

  const [form, setForm] = useState(emptyForm);
  const [rows, setRows] = useState<any[]>([]);
  const [selectedRowId, setSelectedRowId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');
  const [pdfFileName, setPdfFileName] = useState('');
  const [additionalFiles, setAdditionalFiles] = useState<File[]>([]);

  const handle = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleAdditionalFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selected = Array.from(e.target.files);
      setAdditionalFiles((prev) => [...prev, ...selected]);
    }
  };

  const removeAdditionalFile = (index: number) => {
    setAdditionalFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const findCatalogMatch = (part: string) => {
    if (!part) return '';
    const cleanPart = part.trim().toLowerCase();
    const found = catalog.find(
      (c: any) =>
        c.id?.toLowerCase() === cleanPart ||
        c.name?.toLowerCase().includes(cleanPart) ||
        (c.currentGenSku && c.currentGenSku.toLowerCase() === cleanPart) ||
        (c.currentGenModel && c.currentGenModel.toLowerCase().includes(cleanPart))
    );
    if (found) return found.name;
    const option = catalogOptions.find((opt) => opt.toLowerCase().includes(cleanPart));
    return option || part;
  };

  const handleLineItemChange = (name: string, value: string) => {
    const updatedForm = { ...form, [name]: value };

    if (name === 'partNumber') {
      updatedForm.catalog = findCatalogMatch(value);
    }

    setForm(updatedForm);

    if (selectedRowId !== null) {
      setRows((prevRows) =>
        prevRows.map((r) => {
          if (r.id === selectedRowId) {
            const u = name === 'units' ? value : r.units;
            const p = name === 'perUnitCost' ? value : r.perUnitCost;
            const total = (+u || 0) * (+p || 0);

            return {
              ...r,
              [name]: value,
              ...(name === 'partNumber' ? { catalog: findCatalogMatch(value) } : {}),
              units: u,
              perUnitCost: p,
              totalCost: total
            };
          }
          return r;
        })
      );
    }
  };

  // Upload handler triggering the API call and populating from the JSON return
  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      setForm(emptyForm);
      setRows([]);
      setSelectedRowId(null);
      setStatusMsg('');
      setPdfFileName('');
      return;
    }

    setPdfFileName(file.name);
    setLoading(true);
    setStatusMsg('Calling Intake API & parsing document...');

    try {
      const response = await uploadPoFileApi(file);

      if (response && response.success && response.data) {
        const d = response.data;

        // BillTo or DeliverTo Address resolution
        const targetAddress = d.deliverTo?.locationCode?.address || d.billTo?.addressLine1 || d.shipTo?.addressLine1 || '';
        const targetCity = d.deliverTo?.locationCode?.city || d.billTo?.city || d.shipTo?.city || '';
        const targetState = d.deliverTo?.locationCode?.state || d.billTo?.state || '';
        const targetPostal = d.deliverTo?.locationCode?.postalCode || d.billTo?.postalCode || '';
        const targetCountry = d.billTo?.country || d.shipTo?.country || '';

        // Header Population
        const customerName = d.billTo?.company || d.shipTo?.name || d.deliverTo?.glBusinessUnit || 'Customer Entity';
        const supplierName = d.supplier?.name || '';
        const poNumber = d.orderNo || '';
        const entityName = d.deliverTo?.locationCode?.name || d.billTo?.name || '';
        const entityCode = d.deliverTo?.locationCode?.id || '';

        // Line Items extraction from API
        const parsedRows = (d.lineItems || []).map((item, idx) => {
          const part = item.partNumber || 'FN4FC';
          const units = Number(item.quantity ?? 1);
          const perUnitCost = Number(item.unitPrice ?? 0);
          const totalCost = Number(item.netAmount ?? item.amount ?? units * perUnitCost);

          return {
            id: Date.now() + idx,
            partNumber: part,
            catalog: findCatalogMatch(part),
            description: item.description || '',
            customerEntity: entityName,
            entityCode: entityCode,
            units: units.toString(),
            perUnitCost: perUnitCost.toString(),
            totalCost: totalCost,
            billingMethod: 'Monthly'
          };
        });

        // Set Form State with primary line item values
        const firstRow = parsedRows[0] || {};
        setForm({
          poNumber,
          customerName,
          supplier: supplierName,
          shipment: 'Air Freight',
          address1: targetAddress,
          city: targetCity,
          state: targetState,
          pincode: targetPostal,
          country: targetCountry,
          partNumber: firstRow.partNumber || '',
          catalog: firstRow.catalog || '',
          customerEntity: entityName,
          entityCode: entityCode,
          units: firstRow.units || '1',
          perUnitCost: firstRow.perUnitCost || '0',
          billingMethod: 'Monthly'
        });

        setRows(parsedRows);
        if (parsedRows.length > 0) {
          setSelectedRowId(parsedRows[0].id);
        }

        setStatusMsg(`Successfully extracted PO: ${d.orderNo} (${parsedRows.length} items)`);
      } else {
        setStatusMsg('API returned an unsuccessful parsing response.');
      }
    } catch (err: any) {
      console.error('API Error:', err);
      setStatusMsg('Failed to process PO via API.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectRow = (row: any) => {
    setSelectedRowId(row.id);
    setForm((prev) => ({
      ...prev,
      partNumber: row.partNumber || '',
      catalog: row.catalog || '',
      customerEntity: row.customerEntity || '',
      entityCode: row.entityCode || '',
      units: row.units || '',
      perUnitCost: row.perUnitCost || '',
      billingMethod: row.billingMethod || 'Monthly'
    }));
  };

  const handleDeleteRow = (id: number) => {
    const nextRows = rows.filter((r) => r.id !== id);
    setRows(nextRows);

    if (selectedRowId === id) {
      if (nextRows.length > 0) {
        handleSelectRow(nextRows[0]);
      } else {
        setSelectedRowId(null);
        setForm((prev) => ({
          ...prev,
          partNumber: '',
          catalog: '',
          customerEntity: '',
          entityCode: '',
          units: '',
          perUnitCost: ''
        }));
      }
    }
  };

  const handleSubmitPO = () => {
    if (!form.poNumber || !form.customerName) {
      alert('PO Number and Customer Name are required.');
      return;
    }
    if (rows.length === 0) {
      alert('No line items found. Please upload a PO PDF first.');
      return;
    }

    const totalQuantity = rows.reduce((acc, row) => acc + (+row.units || 0), 0);
    const grandTotal = rows.reduce((acc, row) => acc + (+row.totalCost || 0), 0);
    const averageUnitCost = totalQuantity > 0 ? Math.round((grandTotal / totalQuantity) * 100) / 100 : 0;

    const matchedCatalogItem = catalog.find((c: any) =>
      rows.some(
        (r) =>
          (r.catalog && (c.name.toLowerCase().includes(r.catalog.toLowerCase()) || c.id === r.catalog)) ||
          (r.partNumber && (c.currentGenSku?.toLowerCase() === r.partNumber.toLowerCase() || c.id.toLowerCase() === r.partNumber.toLowerCase()))
      )
    );
    const resolvedCatalogItemId = matchedCatalogItem?.id || catalog[0]?.id || 'CAT-14STD';

    intakePO({
      clientName: form.customerName,
      poNumber: form.poNumber,
      source: pdfFileName ? 'PDF_IMPORT' : 'API',
      fileName: pdfFileName || undefined,
      catalogItemId: resolvedCatalogItemId,
      quantity: totalQuantity,
      unitCost: averageUnitCost,
      notes: `Supplier: ${form.supplier || 'N/A'} | Shipment: ${form.shipment} | Items: ${rows.length}`
    });

    navigate('/po');
  };

  // Client-side self-download generator
  const downloadSourceFile = () => {
    const scriptElement = document.getElementById('po-intake-code-content');
    const sourceCode = scriptElement?.innerText || '/* CustomerPOIntake.tsx */';
    const blob = new Blob([sourceCode], { type: 'text/typescript;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'CustomerPOIntake.tsx';
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const totalUnits = rows.reduce((acc, row) => acc + (+row.units || 0), 0);
  const grandTotal = rows.reduce((acc, row) => acc + (+row.totalCost || 0), 0);
  const currentTotalCost = (+form.units || 0) * (+form.perUnitCost || 0);

  return (
    <div className='min-h-screen px-4 py-8 bg-slate-50 sm:px-6 lg:px-8'>
      <div className='mx-auto space-y-6 max-w-7xl'>
        
        {/* Top Header */}
        <div className='flex flex-wrap items-center justify-between gap-4 p-6 bg-white border shadow-sm rounded-2xl border-slate-200'>
          <div>
            <h1 className='text-2xl font-bold text-slate-900'>Customer PO Intake</h1>
            <p className='mt-1 text-sm text-slate-500'>
              Upload PO PDF to parse via API and auto-populate all line-item details.
            </p>
          </div>
          <div className='flex items-center gap-3'>
            {statusMsg && (
              <span
                className={`text-xs font-semibold px-3 py-1.5 rounded-full border ${
                  loading
                    ? 'bg-indigo-50 border-indigo-200 text-indigo-700 animate-pulse'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                }`}
              >
                {statusMsg}
              </span>
            )}
            <button
              type='button'
              onClick={downloadSourceFile}
              className='flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-xs transition-colors'
            >
              <svg className='w-4 h-4 text-slate-500' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth='2' d='M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1M7 10l5 5m0 0l5-5m-5 5V3' />
              </svg>
              Download Component File
            </button>
          </div>
        </div>

        {/* Upload Panels */}
        <div className='grid grid-cols-1 gap-6 md:grid-cols-2'>
          <div className='flex flex-col justify-between p-6 bg-white border shadow-sm rounded-2xl border-slate-200'>
            <div>
              <label className='block mb-1 text-sm font-semibold text-slate-700'>
                Upload Customer PO PDF
              </label>
              <span className='block mb-3 text-xs text-slate-500'>
                Upload your PO PDF document. It will be sent to the extraction API to automatically parse all data.
              </span>
              <input
                id='poPdfUpload'
                type='file'
                accept='.pdf'
                onChange={handlePdfUpload}
                className='hidden'
              />
              <label
                htmlFor='poPdfUpload'
                className={`inline-flex items-center px-4 py-2 text-sm font-semibold text-white rounded-xl shadow-xs transition-colors cursor-pointer ${
                  loading ? 'bg-indigo-400 cursor-wait' : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                {loading ? 'Processing via API...' : 'Upload & Parse PDF'}
              </label>
              {pdfFileName && (
                <span className='block mt-2 font-mono text-xs text-slate-500'>
                  Attached: {pdfFileName}
                </span>
              )}
            </div>
          </div>

          <div className='flex flex-col justify-between p-6 bg-white border shadow-sm rounded-2xl border-slate-200'>
            <div>
              <label className='block mb-1 text-sm font-semibold text-slate-700'>
                Upload Additional Files
              </label>
              <span className='block mb-3 text-xs text-slate-500'>
                Attach supporting documentation (.xlsx, .doc, .msg, .pdf).
              </span>
              <input
                type='file'
                multiple
                accept='.xlsx,.xls,.msg,.doc,.docx,.pdf'
                onChange={handleAdditionalFiles}
                className='block w-full text-sm cursor-pointer text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-100 file:text-slate-700 hover:file:bg-slate-200'
              />
            </div>

            {additionalFiles.length > 0 && (
              <div className='pt-3 mt-4 space-y-1.5 border-t border-slate-100'>
                {additionalFiles.map((file, idx) => (
                  <div key={idx} className='flex items-center justify-between text-xs bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200'>
                    <span className='text-slate-700 truncate font-medium max-w-[280px]'>
                      Additional File {idx + 1}: <span className='font-normal text-slate-500'>{file.name}</span>
                    </span>
                    <button
                      type='button'
                      onClick={() => removeAdditionalFile(idx)}
                      className='ml-2 font-bold transition text-slate-400 hover:text-rose-600'
                      title='Remove file'
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* 1. PO Header Details */}
        <div className='p-6 space-y-4 bg-white border shadow-sm rounded-2xl border-slate-200'>
          <h2 className='text-xs font-bold tracking-wider uppercase text-slate-500'>1. PO Header Details</h2>
          <div className='grid grid-cols-1 gap-4 sm:grid-cols-4'>
            <div>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>PO Number</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                name='poNumber'
                value={form.poNumber}
                onChange={handle}
              />
            </div>
            <div>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>Customer Name</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                name='customerName'
                value={form.customerName}
                onChange={handle}
              />
            </div>
            <div>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>Supplier</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                name='supplier'
                value={form.supplier}
                onChange={handle}
              />
            </div>
            <div>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>Shipment</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                name='shipment'
                value={form.shipment}
                onChange={handle}
              />
            </div>
          </div>
        </div>

        {/* 2. Shipping & Entity Address */}
        <div className='p-6 space-y-4 bg-white border shadow-sm rounded-2xl border-slate-200'>
          <h2 className='text-xs font-bold tracking-wider uppercase text-slate-500'>2. Shipping &amp; Entity Address</h2>
          <div className='grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-5'>
            <div className='md:col-span-2'>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>Address</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200'
                name='address1'
                value={form.address1}
                onChange={handle}
              />
            </div>
            <div>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>Country</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200'
                name='country'
                value={form.country}
                onChange={handle}
              />
            </div>
            <div>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>State</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200'
                name='state'
                value={form.state}
                onChange={handle}
              />
            </div>
            <div>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>City</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200'
                name='city'
                value={form.city}
                onChange={handle}
              />
            </div>
            <div>
              <label className='block mb-1 text-xs font-semibold text-slate-600'>Postal Code</label>
              <input
                className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200'
                name='pincode'
                value={form.pincode}
                onChange={handle}
              />
            </div>
          </div>
        </div>

        {/* 3. Line Items Details Table */}
        <div className='overflow-hidden bg-white border shadow-sm rounded-2xl border-slate-200'>
          <div className='flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50/50'>
            <h2 className='text-xs font-bold tracking-wider uppercase text-slate-600'>
              3. Line Item Details ({rows.length})
            </h2>
            <span className='text-xs text-slate-400'>Click any row to select and edit its values below</span>
          </div>

          <div className='overflow-x-auto'>
            <table className='w-full text-xs text-left'>
              <thead className='font-semibold uppercase border-b bg-slate-50 text-slate-500 border-slate-200'>
                <tr>
                  <th className='p-3'>Part Number</th>
                  <th className='p-3'>Catalog Match</th>
                  <th className='p-3'>Entity / Code</th>
                  <th className='p-3 text-center'>Units</th>
                  <th className='p-3 text-right'>Unit Price</th>
                  <th className='p-3 text-right'>Total</th>
                  <th className='p-3 text-center'>Billing</th>
                  <th className='p-3 text-center'>Delete</th>
                </tr>
              </thead>
              <tbody className='divide-y divide-slate-100'>
                {rows.map((r) => (
                  <tr
                    key={r.id}
                    onClick={() => handleSelectRow(r)}
                    className={`cursor-pointer transition hover:bg-slate-50 ${
                      selectedRowId === r.id ? 'bg-indigo-50/70 font-medium' : ''
                    }`}
                  >
                    <td className='p-3 font-mono font-bold text-indigo-600 underline decoration-indigo-200 underline-offset-2'>
                      {r.partNumber || '—'}
                    </td>
                    <td className='p-3'>
                      {r.catalog ? (
                        <span className='font-semibold text-emerald-700'>{r.catalog}</span>
                      ) : (
                        <span className='font-semibold text-rose-500'>No match</span>
                      )}
                    </td>
                    <td className='p-3'>
                      <div className='font-semibold text-slate-700'>{r.customerEntity || '—'}</div>
                      <div className='text-slate-400 font-mono text-[11px]'>{r.entityCode || ''}</div>
                    </td>
                    <td className='p-3 font-bold text-center text-slate-800'>{r.units}</td>
                    <td className='p-3 font-mono text-right text-slate-700'>
                      ${(+r.perUnitCost || 0).toFixed(2)}
                    </td>
                    <td className='p-3 font-mono font-bold text-right text-slate-900'>
                      ${(+r.totalCost || 0).toFixed(2)}
                    </td>
                    <td className='p-3 text-center text-slate-600'>{r.billingMethod || 'Monthly'}</td>
                    <td className='p-3 text-center' onClick={(e) => e.stopPropagation()}>
                      <button
                        type='button'
                        onClick={() => handleDeleteRow(r.id)}
                        className='p-1 font-bold rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50'
                        title='Delete item'
                      >
                        ✕
                      </button>
                    </td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr>
                    <td colSpan={8} className='p-8 text-center text-slate-400'>
                      No line items registered. Please upload a Customer PO PDF.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className='flex flex-col items-center justify-between p-4 text-xs font-semibold border-t bg-slate-50 border-slate-200 sm:flex-row text-slate-700'>
            <span>Total Units: {totalUnits}</span>
            <span>Grand Total: ${grandTotal.toFixed(2)} USD</span>
          </div>

          {/* Direct Live Editing Form */}
          {rows.length > 0 && (
            <div className='p-5 border-t bg-slate-50/40 border-slate-200'>
              <h3 className='mb-3 text-xs font-bold uppercase text-slate-500'>
                Edit Selected Line Item (Changes apply instantly)
              </h3>
              <div className='grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-4'>
                <div>
                  <label className='block mb-1 text-xs font-semibold text-slate-600'>Part Number</label>
                  <input
                    className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                    name='partNumber'
                    value={form.partNumber}
                    onChange={(e) => handleLineItemChange('partNumber', e.target.value)}
                  />
                </div>
                <div>
                  <label className='block mb-1 text-xs font-semibold text-slate-600'>Catalog Part</label>
                  <select
                    className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                    name='catalog'
                    value={form.catalog}
                    onChange={(e) => handleLineItemChange('catalog', e.target.value)}
                  >
                    <option value=''>Select Item</option>
                    {catalogOptions.map((opt) => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className='block mb-1 text-xs font-semibold text-slate-600'>Entity Name</label>
                  <input
                    className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                    name='customerEntity'
                    value={form.customerEntity}
                    onChange={(e) => handleLineItemChange('customerEntity', e.target.value)}
                  />
                </div>
                <div>
                  <label className='block mb-1 text-xs font-semibold text-slate-600'>Entity Code</label>
                  <input
                    className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                    name='entityCode'
                    value={form.entityCode}
                    onChange={(e) => handleLineItemChange('entityCode', e.target.value)}
                  />
                </div>
                <div>
                  <label className='block mb-1 text-xs font-semibold text-slate-600'>Units</label>
                  <input
                    type='number'
                    className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                    name='units'
                    value={form.units}
                    onChange={(e) => handleLineItemChange('units', e.target.value)}
                  />
                </div>
                <div>
                  <label className='block mb-1 text-xs font-semibold text-slate-600'>Unit Price (USD)</label>
                  <input
                    type='number'
                    className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                    name='perUnitCost'
                    value={form.perUnitCost}
                    onChange={(e) => handleLineItemChange('perUnitCost', e.target.value)}
                  />
                </div>
                <div>
                  <label className='block mb-1 text-xs font-semibold text-slate-600'>Total Cost</label>
                  <input
                    readOnly
                    className='w-full px-3 py-2 text-sm font-semibold border rounded-lg bg-slate-100 border-slate-200 text-slate-600'
                    value={`$${currentTotalCost.toFixed(2)}`}
                  />
                </div>
                <div>
                  <label className='block mb-1 text-xs font-semibold text-slate-600'>Billing Method</label>
                  <select
                    className='w-full px-3 py-2 text-sm bg-white border rounded-lg border-slate-200 focus:ring-2 focus:ring-indigo-500'
                    name='billingMethod'
                    value={form.billingMethod}
                    onChange={(e) => handleLineItemChange('billingMethod', e.target.value)}
                  >
                    <option>Monthly</option>
                    <option>Quarterly</option>
                    <option>OneTime</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Save Purchase Order Button */}
        <div className='flex justify-end'>
          <button
            type='button'
            onClick={handleSubmitPO}
            disabled={rows.length === 0}
            className={`px-6 py-3 rounded-xl font-bold text-sm shadow-md transition ${
              rows.length === 0
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
          >
            Save Customer Purchase Order
          </button>
        </div>

      </div>
    </div>
  );
}