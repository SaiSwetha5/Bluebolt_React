import React, { createContext, useContext, useState, useMemo, useCallback, useRef } from 'react';
import type {
  PurchaseOrder, PurchaseRequisition, VendorOrder, GoodsReceipt, VendorInvoice,
  LeaseSchedule, AssetRecord, AuditLogEntry, CatalogItem, AuditAction,
  VendorName, ShipmentStatus, PrStatus, ModelCategory,
  VendorPurchaseOrder, VendorGrn, GrnLineItem, GrnLineDetail, VendorPoStatus
} from '../types/models';
import type { PrNotification } from '../types/models';
import { PROCUREMENT_MAILBOX } from '../types/models';

function pad(n: number, len = 5): string {
  return n.toString().padStart(len, '0');
}

// ── Seed catalog data ─────────────────────────────────────────────────────────
const SEED_CATALOG: CatalogItem[] = [
  {
    id: 'CAT-14STD', category: 'HW - DaaS Laptop',
    name: 'DaaS Laptop - 14 inch Standard, touch, 16 GB RAM, 1 TB SSD, U5',
    screenSize: '14"', touch: true, ramGb: 16, storageGb: 1000, cpu: 'Intel Core Ultra 5 (U5)',
    clientListPrice: 1699, active: true,
    region: 'APAC', country: 'India', clientCategory: 'Notebooks & Laptops', persona: 'Standard Office Worker',
    shopDescription: 'HP EliteBook 8 G1i 14 AI — 16GB RAM, 1TB SSD, U5',
    longDescription: '14 inch display: touch: 16 GB RAM, 1 TB SSD, U5',
    detailedDescription: 'Standard delivery time: 10–15 business days from approval.',
    modelCategory: '14" Standard Notebook',
    currentGenModel: 'HP EliteBook 8 G1i 14 AI', currentGenSku: 'C40DKEC',
    currentGenConfigDetails: '14 inch display: touch: 16 GB RAM, 1 TB SSD, U5',
    newGenModel: 'HP EliteBook 8 G2i 14 inch', newGenSku: 'WIP',
    newGenConfigDetails: '14 inch display: touch: 16 GB RAM, 1 TB SSD, U5',
    eolTimeline: 'EOL view July 2027 - H2 FY2026',
    serviceClass: 'DaaS Standard', reportingHierarchy: 'HW > Laptops > DaaS', keywords: '',
    vendorMappings: [{ vendor: 'HP', currentGenModel: 'HP EliteBook 8 G1i 14 AI', currentGenSku: 'C40DKEC', currentGenType: 'Non-Modern', newGenModel: 'HP EliteBook 8 G2i 14 inch', npiDate: 'NPI September 2027', unitCost: 1420 }]
  },
  {
    id: 'CAT-16STD', category: 'HW - DaaS Laptop',
    name: 'DaaS Laptop - 16 inch Standard, touch, 16 GB RAM, 1 TB SSD, U5',
    screenSize: '16"', touch: true, ramGb: 16, storageGb: 1000, cpu: 'Intel Core Ultra 5 (U5)',
    clientListPrice: 1799, active: true,
    region: 'APAC', country: 'India', clientCategory: 'Notebooks & Laptops', persona: 'Standard Office Worker',
    shopDescription: 'HP EliteBook 8 G1i 16 AI — 16GB RAM, 1TB SSD, U5',
    longDescription: '15 inch display: touch: 16 GB RAM, 1 TB SSD, U5',
    detailedDescription: 'Standard delivery time: 10–15 business days from approval.',
    modelCategory: '16" Standard Notebook',
    currentGenModel: 'HP EliteBook 8 G1i 16 AI', currentGenSku: 'C3WY0EC',
    currentGenConfigDetails: '15 inch display: touch: 16 GB RAM, 1 TB SSD, U5',
    newGenModel: 'HP EliteBook 8 G2i 16 inch', newGenSku: 'WIP',
    newGenConfigDetails: '15 inch display: touch: 16 GB RAM, 1 TB SSD, U5',
    eolTimeline: 'EOL view July 2027 - H2 FY2026',
    serviceClass: 'DaaS Standard', reportingHierarchy: 'HW > Laptops > DaaS', keywords: '',
    vendorMappings: [{ vendor: 'HP', currentGenModel: 'HP EliteBook 8 G1i 16 AI', currentGenSku: 'C3WY0EC', currentGenType: 'Non-Modern', newGenModel: 'HP EliteBook 8 G2i 16 inch', npiDate: 'NPI September 2027', unitCost: 1550 }]
  },
  {
    id: 'CAT-ULTRA', category: 'HW - DaaS Laptop',
    name: 'DaaS Laptop - Ultralight, UMA i5, 1 TB SSD, 16 GB RAM, No WWAN',
    screenSize: '13"', touch: false, ramGb: 16, storageGb: 1000, cpu: 'Intel Core Ultra 5 (UMA)',
    clientListPrice: 1599, active: true,
    region: 'APAC', country: 'India', clientCategory: 'Notebooks & Laptops', persona: 'Field Technician',
    shopDescription: 'HP EliteBook Ultra G1i AI — UMA i5, 1TB SSD, 16GB RAM, No WWAN',
    longDescription: 'UMA i5 + 1 TB SSD + 16 GB RAM + No WWAN',
    detailedDescription: 'Standard delivery time: 10–15 business days from approval.',
    modelCategory: '"Ultralight" Notebook',
    currentGenModel: 'HP EliteBook Ultra G1i AI', currentGenSku: 'C61MVEC',
    currentGenConfigDetails: 'UMA i5 + 1 TB SSD + 16 GB RAM + No WWAN',
    newGenModel: 'HP EliteBook X G2i', newGenSku: 'WIP',
    newGenConfigDetails: 'UMA i5 + 1 TB SSD + 16 GB RAM + No WWAN',
    eolTimeline: 'EOL view July 2027 - H2 FY2026',
    serviceClass: 'DaaS Standard', reportingHierarchy: 'HW > Laptops > DaaS', keywords: '',
    vendorMappings: [{ vendor: 'HP', currentGenModel: 'HP EliteBook Ultra G1i AI', currentGenSku: 'C61MVEC', currentGenType: 'Non-Modern', newGenModel: 'HP EliteBook X G2i', npiDate: 'NPI September 2027', unitCost: 1480 }]
  },
  {
    id: 'CAT-CONV', category: 'HW - DaaS Laptop',
    name: 'DaaS Laptop - Convertible, U5, 1 TB SSD, 16 GB RAM, WWAN',
    screenSize: '14"', touch: true, ramGb: 16, storageGb: 1000, cpu: 'Intel Core Ultra 5 (U5)',
    clientListPrice: 1899, active: true,
    region: 'APAC', country: 'India', clientCategory: 'Notebooks & Laptops', persona: 'Executive',
    shopDescription: 'HP EliteBook X Flip G1i AI — U5, 1TB SSD, 16GB RAM + WWAN',
    longDescription: 'U5 + 1 TB SSD + 16 GB RAM + WWAN',
    detailedDescription: 'Standard delivery time: 10–15 business days from approval.',
    modelCategory: '"Convertible" Notebook',
    currentGenModel: 'HP EliteBook X Flip G1i AI', currentGenSku: 'C2ZK6EC',
    currentGenConfigDetails: 'U5 + 1 TB SSD + 16 GB RAM + WWAN',
    newGenModel: 'HP EliteBook X Flip G2i AI', newGenSku: 'WIP',
    newGenConfigDetails: 'U5 + 1 TB SSD + 16 GB RAM + WWAN',
    eolTimeline: 'EOL view July 2027 - H2 FY2026',
    serviceClass: 'DaaS Standard', reportingHierarchy: 'HW > Laptops > DaaS', keywords: '',
    vendorMappings: [
      { vendor: 'HP', currentGenModel: 'HP EliteBook X Flip G1i AI', currentGenSku: 'C2ZK6EC', currentGenType: 'Non-Modern', newGenModel: 'HP EliteBook X Flip G2i AI', npiDate: 'NPI September 2027', unitCost: 1540 },
      { vendor: 'Dell', currentGenModel: 'Dell Latitude 7440 2-in-1', currentGenSku: 'LAT7440-U5-14', currentGenType: 'Modern', newGenModel: 'Dell Latitude 7450 2-in-1', npiDate: 'NPI September 2027', unitCost: 1510 },
      { vendor: 'Lenovo', currentGenModel: 'Lenovo ThinkPad X13 2-in-1 G5', currentGenSku: 'X13G5-U5-14', currentGenType: 'Modern', newGenModel: 'Lenovo ThinkPad X13 2-in-1 G6', npiDate: 'NPI September 2027', unitCost: 1495 }
    ]
  },
  {
    id: 'CAT-MICRODT', category: 'HW - DaaS Desktop',
    name: 'DaaS Micro Desktop - Intel Core i5, 16 GB, 1 TB SSD + WLAN',
    screenSize: 'N/A', touch: false, ramGb: 16, storageGb: 1000, cpu: 'Intel Core i5',
    clientListPrice: 1299, active: true,
    region: 'APAC', country: 'India', clientCategory: 'Desktops', persona: 'Standard Office Worker',
    shopDescription: 'HP EliteDesk 8 G1i Mini — Core i5, 16GB, 1TB SSD + WLAN',
    longDescription: 'Intel Core i5 / 16 GB / 1TB SSD + WLAN',
    detailedDescription: 'Standard delivery time: 10–15 business days from approval.',
    modelCategory: 'Micro Desktops',
    currentGenModel: 'HP EliteDesk 8 G1i Mini', currentGenSku: 'C41QWEC',
    currentGenConfigDetails: 'Intel Core i5 / 16 GB / 1TB SSD + WLAN',
    newGenModel: 'HP EliteDesk 8 G2i Mini', newGenSku: 'WIP',
    newGenConfigDetails: 'Intel Core i5 / 16 GB / 1TB SSD + WLAN',
    eolTimeline: 'EOL view July 2027 - H2 FY2026',
    serviceClass: 'DaaS Standard', reportingHierarchy: 'HW > Desktops > DaaS', keywords: '',
    vendorMappings: [{ vendor: 'HP', currentGenModel: 'HP EliteDesk 8 G1i Mini', currentGenSku: 'C41QWEC', currentGenType: 'Modern', newGenModel: 'HP EliteDesk 8 G2i Mini', npiDate: 'NPI September 2027', unitCost: 1100 }]
  },
  {
    id: 'CAT-PERF-I9', category: 'HW - DaaS Laptop',
    name: 'DaaS Laptop - Performance i9, 2TB SSD, 64GB RAM, RTX 3000 Blackwell',
    screenSize: '16"', touch: false, ramGb: 64, storageGb: 2000, cpu: 'Intel Core i9-285HX',
    clientListPrice: 3499, active: true,
    region: 'APAC', country: 'India', clientCategory: 'Workstation Notebooks', persona: 'Power User',
    shopDescription: 'HP ZBook Fury G1i 16 O2O — i9, 64GB, 2TB, RTX 3000 Blackwell',
    longDescription: 'i9-285HX / 2TB SSD / 64GB / RTX 3000 Blackwell / No WWAN / Fingerprint / No NFC / Webcam',
    detailedDescription: 'High-performance mobile workstation. Standard delivery time: 15–20 business days from approval.',
    modelCategory: 'Performance Notebook (i9)',
    currentGenModel: 'HP ZBook Fury G1i 16 O2O', currentGenSku: 'C2EL5EC',
    currentGenConfigDetails: 'i9-285HX / 2TB SSD / 64GB / RTX 3000 Blackwell / No WWAN / Fingerprint / No NFC / Webcam',
    newGenModel: 'Unchanged', newGenSku: 'Unchanged',
    newGenConfigDetails: 'i9-285HX / 2TB SSD / 64GB / RTX 3000 Blackwell / No WWAN / Fingerprint / No NFC / Webcam',
    eolTimeline: 'EOL view July 2027 - H2 FY2026',
    serviceClass: 'DaaS Premium', reportingHierarchy: 'HW > Workstations > DaaS', keywords: '',
    vendorMappings: [{ vendor: 'HP', currentGenModel: 'HP ZBook Fury G1i 16 O2O', currentGenSku: 'C2EL5EC', currentGenType: 'Modern', newGenModel: 'Unchanged', npiDate: 'Unchanged', unitCost: 3200 }]
  },
  {
    id: 'CAT-PERF-I7', category: 'HW - DaaS Laptop',
    name: 'DaaS Laptop - Performance i7, 2TB SSD, 64GB RAM, RTX 2000 Blackwell',
    screenSize: '16"', touch: false, ramGb: 64, storageGb: 2000, cpu: 'Intel U7 265HX',
    clientListPrice: 2999, active: true,
    region: 'APAC', country: 'India', clientCategory: 'Workstation Notebooks', persona: 'Power User',
    shopDescription: 'HP ZBook Fury G1i 16, i7 265HX, 2TB, 64 GB, RTX 2000 Blackwell',
    longDescription: 'Intel U7 265HX, 16 WUXGA BV LED UWVA TS, DSC, Webcam, 64GB DDR5, 2.0TB SSD, be+BT, 8C Batt, FPS, W11 Pro64',
    detailedDescription: 'High-performance mobile workstation. Standard delivery time: 15–20 business days from approval.',
    modelCategory: 'Performance Notebook',
    currentGenModel: 'HP ZBook Fury G1i 16, i7 265HX', currentGenSku: 'DA3X7EC',
    currentGenConfigDetails: 'Intel U7 265HX, 16 WUXGA BV LED UWVA TS, DSC, Webcam, 64GB DDR5, 2.0TB SSD, be+BT, 8C Batt, FPS, W11 Pro64',
    newGenModel: 'HP ZBook Fury G1i 16, i7 265HX', newGenSku: 'DA3X7EC',
    newGenConfigDetails: 'Intel U7 265HX, 16 WUXGA BV LED UWVA TS, DSC, Webcam, 64GB DDR5, 2.0TB SSD, be+BT, 8C Batt, FPS, W11 Pro64',
    eolTimeline: 'EOL view July 2027 - H2 FY2026',
    serviceClass: 'DaaS Premium', reportingHierarchy: 'HW > Workstations > DaaS', keywords: '',
    vendorMappings: [{ vendor: 'HP', currentGenModel: 'HP ZBook Fury G1i 16, i7 265HX', currentGenSku: 'DA3X7EC', currentGenType: 'Modern', newGenModel: 'HP ZBook Fury G1i 16, i7 265HX', npiDate: 'Unchanged', unitCost: 2750 }]
  },
  {
    id: 'CAT-PERFDT', category: 'HW - DaaS Desktop',
    name: 'DaaS Desktop - Performance, U7-265K, 2TB SSD, 64GB, RTX A2000',
    screenSize: 'N/A', touch: false, ramGb: 64, storageGb: 2000, cpu: 'Intel U7-265K',
    clientListPrice: 2799, active: true,
    region: 'APAC', country: 'India', clientCategory: 'Desktops', persona: 'Power User',
    shopDescription: 'HP Z2 Tower G1i — U7-265K, 2TB SSD, 64GB, RTX A2000 + Mouse/Keyboard',
    longDescription: 'U7-265K / 2TB SSD / 64GB / RTX A2000 / incl. Mouse / keyboard',
    detailedDescription: 'Standard delivery time: 15–20 business days from approval.',
    modelCategory: 'Performance Desktops',
    currentGenModel: 'HP Z2 Tower G1i', currentGenSku: 'C2LW9EC',
    currentGenConfigDetails: 'U7-265K / 2TB SSD / 64GB / RTX A2000 / incl. Mouse / keyboard',
    newGenModel: 'HP Z2 Tower G1i', newGenSku: 'C2LW9EC',
    newGenConfigDetails: 'U7-265K / 2TB SSD / 64GB / RTX A2000 / incl. Mouse / keyboard',
    eolTimeline: 'EOL view July 2027 - H2 FY2026',
    serviceClass: 'DaaS Standard', reportingHierarchy: 'HW > Desktops > DaaS', keywords: '',
    vendorMappings: [{ vendor: 'HP', currentGenModel: 'HP Z2 Tower G1i', currentGenSku: 'C2LW9EC', currentGenType: 'Modern', newGenModel: 'HP Z2 Tower G1i', npiDate: 'Unchanged', unitCost: 2500 }]
  },
];

// ── Context type ──────────────────────────────────────────────────────────────
export interface DataContextValue {
  // State
  purchaseOrders: PurchaseOrder[];
  purchaseRequisitions: PurchaseRequisition[];
  vendorOrders: VendorOrder[];
  goodsReceipts: GoodsReceipt[];
  invoices: VendorInvoice[];
  leaseSchedules: LeaseSchedule[];
  assets: AssetRecord[];
  auditLog: AuditLogEntry[];
  catalog: CatalogItem[];
  vendorPurchaseOrders: VendorPurchaseOrder[];
  vendorGrns: VendorGrn[];
  notifications: PrNotification[];
  dashboardStats: {
    totalPOs: number; pendingApproval: number; approved: number;
    inProcurement: number; inTransit: number; delivered: number;
    invoiceExceptions: number; totalAssets: number; deployedAssets: number;
    totalDevicesRequested: number; pendingPrApprovals: number; unreadNotifications: number;
  };
  // Audit
  auditFor: (entityId: string) => AuditLogEntry[];
  // Notifications
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  // PO
  intakePO: (input: Omit<PurchaseOrder, 'id' | 'status' | 'submittedAt'>) => PurchaseOrder;
  approvePO: (poId: string, approver: string) => void;
  rejectPO: (poId: string, approver: string, reason: string) => void;
  // Warehouse stock
  availableWarehouseStock: (catalogItemId: string) => number;
  onOrderQuantity: (catalogItemId: string) => number;
  fulfillFromWarehouse: (poId: string, catalogItemId: string, qty: number) => number;
  // PR
  createPurchaseRequisition: (input: { poId: string; requestedQty: number; preferredVendor?: VendorName; estimatedUnitCost: number; costCenter: string; justification: string; requestedBy: string; }) => PurchaseRequisition;
  submitPrForApproval: (prId: string) => void;
  emailPrForApproval: (prId: string, approverEmail: string) => void;
  approvePr: (prId: string, approver: string) => void;
  rejectPr: (prId: string, approver: string, reason: string) => void;
  markPrConverted: (prId: string) => void;
  // Vendor orders
  createVendorOrder: (input: { poId: string; requestId: string; prId?: string; vendor: VendorName; vendorSku: string; channel: VendorOrder['channel']; quantity: number; unitCost: number; destination: VendorOrder['destination']; modelCategory?: ModelCategory; currentGeneration?: string; sku1NonModern?: string; newGeneration?: string; catalogItemId: string; warehouseAddress?: string; cognizantPoOverride?: string; }) => VendorOrder;
  submitVendorOrder: (voId: string) => void;
  advanceVendorOrderStatus: (voId: string, status: VendorOrder['status'], extra?: Partial<VendorOrder>) => void;
  addShipmentEvent: (voId: string, status: ShipmentStatus, location?: string, note?: string) => void;
  // Warehouse GRN
  createGoodsReceipt: (input: Omit<GoodsReceipt, 'id' | 'receivedAt'>) => GoodsReceipt;
  // Vendor PO → GRN
  vendorPo: (poId: string) => VendorPurchaseOrder | undefined;
  grnsForPo: (poId: string) => VendorGrn[];
  alreadyGrnQty: (poId: string, lineItemId: string) => number;
  remainingQty: (poId: string, lineItemId: string) => number;
  createVendorGrn: (input: { poId: string; createdBy: string; lines: { lineItemId: string; itemName: string; poQty: number; grnQty: number; rate: number; details: GrnLineDetail }[] }) => VendorGrn;
  approveVendorGrn: (grnId: string, approver: string) => void;
  rejectVendorGrn: (grnId: string, approver: string, reason: string) => void;
  // Finance
  submitInvoice: (input: Omit<VendorInvoice, 'id' | 'status' | 'matchResult'>) => VendorInvoice;
  approveInvoicePayment: (invoiceId: string, approver: string) => void;
  markInvoicePaid: (invoiceId: string) => void;
  createLeaseSchedule: (input: Omit<LeaseSchedule, 'id' | 'status'>) => LeaseSchedule;
  // Inventory
  assignAsset: (assetId: string, user: string, location: string) => void;
  retireAsset: (assetId: string) => void;
  // Catalog
  upsertCatalogItem: (item: CatalogItem, isNew: boolean) => void;
}

const DataContext = createContext<DataContextValue | null>(null);

export function useData(): DataContextValue {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}

// ── Provider ──────────────────────────────────────────────────────────────────
export function DataProvider({ children }: { children: React.ReactNode }) {
  const counters = useRef({ po: 417, req: 900, vo: 118, grn: 212, inv: 8821, ls: 41, ast: 451, audit: 1, pr: 301, notif: 1, vgrn: 26270004 });

  const [purchaseOrders, setPurchaseOrders]       = useState<PurchaseOrder[]>([]);
  const [purchaseRequisitions, setPRs]            = useState<PurchaseRequisition[]>([]);
  const [vendorOrders, setVendorOrders]           = useState<VendorOrder[]>([]);
  const [goodsReceipts, setGoodsReceipts]         = useState<GoodsReceipt[]>([]);
  const [invoices, setInvoices]                   = useState<VendorInvoice[]>([]);
  const [leaseSchedules, setLeaseSchedules]       = useState<LeaseSchedule[]>([]);
  const [assets, setAssets]                       = useState<AssetRecord[]>([]);
  const [auditLog, setAuditLog]                   = useState<AuditLogEntry[]>([]);
  const [catalog, setCatalog]                     = useState<CatalogItem[]>([]);
  const [vendorPurchaseOrders, setVendorPOs]      = useState<VendorPurchaseOrder[]>([]);
  const [vendorGrns, setVendorGrns]               = useState<VendorGrn[]>([]);
  const [notifications, setNotifications]         = useState<PrNotification[]>([]);

  // ── helpers (using refs to avoid stale closures in seed) ─────────────────
  const posRef         = useRef<PurchaseOrder[]>([]);
  const prsRef         = useRef<PurchaseRequisition[]>([]);
  const vosRef         = useRef<VendorOrder[]>([]);
  const assetsRef      = useRef<AssetRecord[]>([]);
  const catalogRef     = useRef<CatalogItem[]>([]);
  const invoicesRef    = useRef<VendorInvoice[]>([]);
  const vendorPOsRef   = useRef<VendorPurchaseOrder[]>([]);
  const vendorGrnsRef  = useRef<VendorGrn[]>([]);
  const auditRef       = useRef<AuditLogEntry[]>([]);
  const notifsRef      = useRef<PrNotification[]>([]);

  const setPOs2 = (fn: (l: PurchaseOrder[]) => PurchaseOrder[]) => {
    const next = fn(posRef.current);
    posRef.current = next;
    setPurchaseOrders(next);
  };
  const setPRs2 = (fn: (l: PurchaseRequisition[]) => PurchaseRequisition[]) => {
    const next = fn(prsRef.current);
    prsRef.current = next;
    setPRs(next);
  };
  const setVOs2 = (fn: (l: VendorOrder[]) => VendorOrder[]) => {
    const next = fn(vosRef.current);
    vosRef.current = next;
    setVendorOrders(next);
  };
  const setAssets2 = (fn: (l: AssetRecord[]) => AssetRecord[]) => {
    const next = fn(assetsRef.current);
    assetsRef.current = next;
    setAssets(next);
  };
  const setInvoices2 = (fn: (l: VendorInvoice[]) => VendorInvoice[]) => {
    const next = fn(invoicesRef.current);
    invoicesRef.current = next;
    setInvoices(next);
  };
  const setVendorPOs2 = (fn: (l: VendorPurchaseOrder[]) => VendorPurchaseOrder[]) => {
    const next = fn(vendorPOsRef.current);
    vendorPOsRef.current = next;
    setVendorPOs(next);
  };
  const setVendorGrns2 = (fn: (l: VendorGrn[]) => VendorGrn[]) => {
    const next = fn(vendorGrnsRef.current);
    vendorGrnsRef.current = next;
    setVendorGrns(next);
  };
  const setAudit2 = (fn: (l: AuditLogEntry[]) => AuditLogEntry[]) => {
    const next = fn(auditRef.current);
    auditRef.current = next;
    setAuditLog(next);
  };
  const setNotifs2 = (fn: (l: PrNotification[]) => PrNotification[]) => {
    const next = fn(notifsRef.current);
    notifsRef.current = next;
    setNotifications(next);
  };

  // ── Audit ─────────────────────────────────────────────────────────────────
  function logAudit(action: AuditAction, entityType: AuditLogEntry['entityType'], entityId: string, details: string, actor = 'system'): void {
    const entry: AuditLogEntry = {
      id: 'AUD-' + pad(counters.current.audit++),
      timestamp: new Date().toISOString(),
      action, entityType, entityId, actor, details
    };
    setAudit2(l => [entry, ...l]);
  }

  function pushNotification(n: Omit<PrNotification, 'id' | 'timestamp' | 'read'>): void {
    const notif: PrNotification = {
      ...n,
      id: 'NOTIF-' + pad(counters.current.notif++),
      timestamp: new Date().toISOString(),
      read: false
    };
    setNotifs2(l => [notif, ...l]);
  }

  // ── PO ───────────────────────────────────────────────────────────────────
  function acknowledgePO(poId: string): void {
    const requestId = 'REQ-2026-' + pad(counters.current.req++);
    setPOs2(list => list.map(p => p.id === poId ? { ...p, status: 'ACKNOWLEDGED', requestId, acknowledgedAt: new Date().toISOString() } : p));
    logAudit('PO_ACKNOWLEDGED', 'PO', poId, `Acknowledgment sent to client. Request ${requestId} generated.`);
    setPOs2(list => list.map(p => p.id === poId ? { ...p, status: 'PENDING_APPROVAL' } : p));
  }

  function intakePO(input: Omit<PurchaseOrder, 'id' | 'status' | 'submittedAt'>): PurchaseOrder {
    const po: PurchaseOrder = { ...input, id: 'PO-2026-' + pad(counters.current.po++), status: 'RECEIVED', submittedAt: new Date().toISOString() };
    setPOs2(l => [po, ...l]);
    logAudit('PO_RECEIVED', 'PO', po.id, `PO ${po.poNumber} received from ${po.clientName} for ${po.quantity} units via ${po.source === 'PDF_IMPORT' ? 'PDF import' : 'API integration'}.`);
    setTimeout(() => acknowledgePO(po.id), 0);
    return po;
  }

  function approvePO(poId: string, approver: string): void {
    setPOs2(list => list.map(p => p.id === poId ? { ...p, status: 'APPROVED', approvedAt: new Date().toISOString(), approvedBy: approver } : p));
    logAudit('PO_APPROVED', 'PO', poId, `PO approved by ${approver}. Routed to warehouse for fulfillment instructions.`, approver);
  }

  function rejectPO(poId: string, approver: string, reason: string): void {
    setPOs2(list => list.map(p => p.id === poId ? { ...p, status: 'REJECTED', rejectedReason: reason } : p));
    logAudit('PO_REJECTED', 'PO', poId, `PO rejected by ${approver}. Reason: ${reason}`, approver);
  }

  // ── Warehouse stock ────────────────────────────────────────────────────────
  function availableWarehouseStock(catalogItemId: string): number {
    return assetsRef.current.filter(a => a.catalogItemId === catalogItemId && a.lifecycleStatus === 'IN_STOCK' && a.location === 'Cognizant Warehouse').length;
  }

  function onOrderQuantity(catalogItemId: string): number {
    const poCatalogById = new Map(posRef.current.map(p => [p.id, p.catalogItemId]));
    return vosRef.current.filter(v => poCatalogById.get(v.poId) === catalogItemId && v.status !== 'DELIVERED' && v.status !== 'CANCELLED').reduce((sum, v) => sum + v.quantity, 0);
  }

  function fulfillFromWarehouse(poId: string, catalogItemId: string, qty: number): number {
    const candidates = assetsRef.current.filter(a => a.catalogItemId === catalogItemId && a.lifecycleStatus === 'IN_STOCK' && a.location === 'Cognizant Warehouse').slice(0, qty);
    if (candidates.length === 0) return 0;
    const ids = new Set(candidates.map(a => a.assetId));
    setAssets2(list => list.map(a => ids.has(a.assetId) ? { ...a, poId } : a));
    logAudit('ASSET_ASSIGNED', 'Asset', candidates.map(a => a.assetId).join(', '), `${candidates.length} unit(s) reassigned from warehouse stock to fulfill ${poId}.`);
    return candidates.length;
  }

  // ── PR ────────────────────────────────────────────────────────────────────
  function createPurchaseRequisition(input: { poId: string; requestedQty: number; preferredVendor?: VendorName; estimatedUnitCost: number; costCenter: string; justification: string; requestedBy: string; }): PurchaseRequisition {
    const po = posRef.current.find(p => p.id === input.poId);
    if (!po) throw new Error('Customer PO not found for requisition.');
    const requestId = po.requestId || ('REQ-2026-' + pad(counters.current.req++));
    if (!po.requestId) setPOs2(list => list.map(p => p.id === po.id ? { ...p, requestId } : p));
    const inStockQty = availableWarehouseStock(po.catalogItemId);
    const onOrderQty = onOrderQuantity(po.catalogItemId);
    const balanceQty = Math.max(input.requestedQty - inStockQty - onOrderQty, 0);
    const pr: PurchaseRequisition = {
      id: 'PR-2026-' + pad(counters.current.pr++),
      poId: po.id, requestId, catalogItemId: po.catalogItemId,
      requestedQty: input.requestedQty, inStockQty, onOrderQty, balanceQty,
      preferredVendor: input.preferredVendor,
      estimatedUnitCost: input.estimatedUnitCost,
      estimatedTotalCost: balanceQty * input.estimatedUnitCost,
      costCenter: input.costCenter, justification: input.justification,
      requestedBy: input.requestedBy, requestedAt: new Date().toISOString(), status: 'DRAFT'
    };
    setPRs2(l => [pr, ...l]);
    logAudit('PR_CREATED', 'PR', pr.id, `Requisition raised for ${pr.requestedQty} unit(s) against ${po.id}. In stock: ${inStockQty}, on order: ${onOrderQty}, balance to procure: ${balanceQty}.`, input.requestedBy);
    return pr;
  }

  function submitPrForApproval(prId: string): void {
    setPRs2(list => list.map(pr => pr.id === prId ? { ...pr, status: 'PENDING_APPROVAL' as PrStatus } : pr));
    logAudit('PR_SUBMITTED_FOR_APPROVAL', 'PR', prId, `Requisition submitted for approval.`);
  }

  function emailPrForApproval(prId: string, approverEmail: string): void {
    const now = new Date().toISOString();
    setPRs2(list => list.map(pr => pr.id === prId ? { ...pr, emailedTo: approverEmail, emailedAt: now, approvalNotificationSentTo: PROCUREMENT_MAILBOX, approvalNotificationSentAt: now } : pr));
    logAudit('PR_EMAILED', 'PR', prId, `Approval request emailed to ${approverEmail}.`);
    logAudit('PR_APPROVAL_NOTIFICATION_SENT', 'PR', prId, `Approval notification copy routed to procurement mailbox (${PROCUREMENT_MAILBOX}).`);
    const pr = prsRef.current.find(p => p.id === prId);
    if (pr) {
      pushNotification({
        type: 'APPROVAL_REQUESTED', prId,
        subject: `Approval needed: ${prId} — ${pr.balanceQty} unit(s) to procure`,
        body: `${pr.requestedBy} submitted ${prId} for approval. Estimated spend: $${pr.estimatedTotalCost.toLocaleString()}. Approver notified: ${approverEmail}.`,
        to: PROCUREMENT_MAILBOX,
      });
    }
  }

  function approvePr(prId: string, approver: string): void {
    const now = new Date().toISOString();
    setPRs2(list => list.map(pr => pr.id === prId ? { ...pr, status: 'APPROVED' as PrStatus, approvedBy: approver, approvedAt: now, procurementNotificationSentTo: PROCUREMENT_MAILBOX, procurementNotificationSentAt: now } : pr));
    const pr = prsRef.current.find(p => p.id === prId);
    const po = pr ? posRef.current.find(p => p.id === pr.poId) : undefined;
    if (po && po.status !== 'APPROVED') {
      setPOs2(list => list.map(p => p.id === po.id ? { ...p, status: 'APPROVED', approvedAt: now, approvedBy: approver } : p));
      logAudit('PO_APPROVED', 'PO', po.id, `Customer PO status updated to APPROVED following PR ${prId} approval by ${approver}.`, approver);
    }
    const catalogItem = pr ? catalogRef.current.find(c => c.id === pr.catalogItemId) : undefined;
    logAudit('PR_APPROVED', 'PR', prId, `Requisition approved by ${approver}. Balance qty: ${pr?.balanceQty ?? '?'}, estimated spend: $${pr?.estimatedTotalCost?.toLocaleString() ?? '?'}.`, approver);
    logAudit('PR_PROCUREMENT_NOTIFICATION_SENT', 'PR', prId, `Approval confirmation and procurement trigger routed to ${PROCUREMENT_MAILBOX}.`);
    if (pr) {
      pushNotification({
        type: 'PR_APPROVED', prId,
        subject: `PR Approved — raise Cognizant PO for ${prId}`,
        body: [
          `${prId} was approved by ${approver}.`, ``,
          `Customer PO: ${pr.poId}${po ? ' (' + po.clientName + ', PO# ' + po.poNumber + ')' : ''}`,
          `Catalog item: ${catalogItem?.name ?? pr.catalogItemId}`,
          `Balance quantity to procure: ${pr.balanceQty}`,
          `Preferred vendor: ${pr.preferredVendor ?? 'Not specified'}`,
          `Estimated unit cost: $${pr.estimatedUnitCost.toLocaleString()}`,
          `Estimated total spend: $${pr.estimatedTotalCost.toLocaleString()}`,
          `Cost center: ${pr.costCenter}`, ``,
          `Action required: raise a Cognizant PO against this approved requisition in Asset360.`,
        ].join('\n'),
        to: PROCUREMENT_MAILBOX,
      });
    }
  }

  function rejectPr(prId: string, approver: string, reason: string): void {
    setPRs2(list => list.map(pr => pr.id === prId ? { ...pr, status: 'REJECTED' as PrStatus, approvedBy: approver, rejectedReason: reason } : pr));
    logAudit('PR_REJECTED', 'PR', prId, `Requisition rejected by ${approver}. Reason: ${reason}`, approver);
    const pr = prsRef.current.find(p => p.id === prId);
    if (pr) {
      pushNotification({
        type: 'PR_REJECTED', prId,
        subject: `PR Rejected — ${prId}`,
        body: `${prId} was rejected by ${approver}. Reason: ${reason}. Requested by: ${pr.requestedBy}.`,
        to: PROCUREMENT_MAILBOX,
      });
    }
  }

  function markPrConverted(prId: string): void {
    setPRs2(list => list.map(pr => pr.id === prId ? { ...pr, status: 'CONVERTED' as PrStatus } : pr));
    logAudit('PR_CONVERTED', 'PR', prId, `Requisition converted into a Cognizant PO / vendor order.`);
  }

  // ── Vendor Orders ──────────────────────────────────────────────────────────
  function createVendorOrder(input: { poId: string; requestId: string; prId?: string; vendor: VendorName; vendorSku: string; channel: VendorOrder['channel']; quantity: number; unitCost: number; destination: VendorOrder['destination']; modelCategory?: ModelCategory; currentGeneration?: string; sku1NonModern?: string; newGeneration?: string; catalogItemId: string; warehouseAddress?: string; cognizantPoOverride?: string; }): VendorOrder {
    const n = counters.current.vo++;
    const { cognizantPoOverride, ...rest } = input;
    const vo: VendorOrder = {
      ...rest, id: 'VO-2026-' + pad(n),
      cognizantPoNumber: cognizantPoOverride?.trim() || 'CGZ-PO-2026-' + pad(n),
      status: 'DRAFT', createdAt: new Date().toISOString(), shipmentHistory: []
    };
    setVOs2(l => [vo, ...l]);
    logAudit('VENDOR_ORDER_CREATED', 'VendorOrder', vo.id, `Cognizant PO ${vo.cognizantPoNumber} drafted with ${vo.vendor} for ${vo.quantity} units (SKU ${vo.vendorSku}) via ${vo.channel}, fulfilling customer PO ${vo.poId}${vo.prId ? ` (requisition ${vo.prId})` : ''}.`);
    return vo;
  }

  function submitVendorOrder(voId: string): void {
    setVOs2(list => list.map(v => v.id === voId ? { ...v, status: 'SUBMITTED', submittedAt: new Date().toISOString() } : v));
    logAudit('VENDOR_ORDER_SUBMITTED', 'VendorOrder', voId, `Order submitted to vendor procurement channel.`);
  }

  function advanceVendorOrderStatus(voId: string, status: VendorOrder['status'], extra?: Partial<VendorOrder>): void {
    setVOs2(list => list.map(v => v.id === voId ? { ...v, status, ...extra } : v));
    logAudit('VENDOR_ORDER_STATUS_CHANGED', 'VendorOrder', voId, `Status changed to ${status}.`);
  }

  function addShipmentEvent(voId: string, status: ShipmentStatus, location?: string, note?: string): void {
    setVOs2(list => list.map(v => v.id === voId ? {
      ...v,
      shipmentStatus: status,
      shipmentHistory: [...v.shipmentHistory, { status, timestamp: new Date().toISOString(), location, note }],
      status: status === 'DELIVERED' ? 'DELIVERED' : (status === 'IN_TRANSIT' || status === 'OUT_FOR_DELIVERY') ? 'SHIPPED' : v.status
    } : v));
    logAudit('SHIPMENT_UPDATE', 'VendorOrder', voId, `Shipment status: ${status}${location ? ' @ ' + location : ''}.`);
  }

  // ── GRN (warehouse) ────────────────────────────────────────────────────────
  function createGoodsReceipt(input: Omit<GoodsReceipt, 'id' | 'receivedAt'>): GoodsReceipt {
    const grn: GoodsReceipt = { ...input, id: 'GRN-2026-' + pad(counters.current.grn++), receivedAt: new Date().toISOString() };
    setGoodsReceipts(l => [grn, ...l]);
    logAudit('POD_CAPTURED', 'GRN', grn.id, `Proof of delivery captured (${grn.podFileName ?? 'no file'}).`);
    logAudit('GRN_GENERATED', 'GRN', grn.id, `GRN generated for vendor order ${grn.vendorOrderId}: ${grn.quantityReceived}/${grn.quantityExpected} units, condition ${grn.condition}.`);
    const vo = vosRef.current.find(v => v.id === grn.vendorOrderId);
    const po = posRef.current.find(p => p.id === grn.poId);
    const item = po ? catalogRef.current.find(c => c.id === po.catalogItemId) : undefined;
    const mapping = item?.vendorMappings.find(m => vo && m.vendor === vo.vendor);
    if (vo && po) {
      const newAssets: AssetRecord[] = Array.from({ length: grn.quantityReceived }).map(() => {
        const assetId = 'AST-' + pad(counters.current.ast++, 6);
        return {
          assetId,
          serialNumber: 'SN' + Math.random().toString(36).slice(2, 10).toUpperCase(),
          deviceType: 'Laptop' as const,
          vendor: vo.vendor,
          model: mapping?.newGenModel ?? mapping?.currentGenModel ?? item?.name ?? 'Unknown Model',
          catalogItemId: po.catalogItemId,
          cost: vo.unitCost,
          location: 'Cognizant Warehouse',
          shipmentStatus: 'DELIVERED' as const,
          lifecycleStatus: 'IN_STOCK' as const,
          poId: po.id, vendorOrderId: vo.id, grnId: grn.id
        };
      });
      setAssets2(l => [...newAssets, ...l]);
      newAssets.forEach(a => logAudit('ASSET_CREATED', 'Asset', a.assetId, `Asset registered in CMDB from GRN ${grn.id}.`));
    }
    return grn;
  }

  // ── Vendor PO → GRN (multi-line) ───────────────────────────────────────────
  function vendorPo(poId: string): VendorPurchaseOrder | undefined {
    return vendorPOsRef.current.find(p => p.id === poId);
  }

  function grnsForPo(poId: string): VendorGrn[] {
    return vendorGrnsRef.current.filter(g => g.poId === poId).sort((a, b) => b.grnDate.localeCompare(a.grnDate));
  }

  function alreadyGrnQty(poId: string, lineItemId: string): number {
    return vendorGrnsRef.current
      .filter(g => g.poId === poId && g.status !== 'REJECTED')
      .reduce((sum, g) => sum + (g.lines.find(l => l.lineItemId === lineItemId)?.grnQty ?? 0), 0);
  }

  function remainingQty(poId: string, lineItemId: string): number {
    const po = vendorPo(poId);
    const line = po?.lineItems.find(l => l.id === lineItemId);
    if (!line) return 0;
    return Math.max(line.poQty - alreadyGrnQty(poId, lineItemId), 0);
  }

  function createVendorGrn(input: { poId: string; createdBy: string; lines: { lineItemId: string; itemName: string; poQty: number; grnQty: number; rate: number; details: GrnLineDetail }[] }): VendorGrn {
    const po = vendorPo(input.poId);
    if (!po) throw new Error('Vendor PO not found.');
    const lines: GrnLineItem[] = input.lines
      .filter(l => l.grnQty > 0)
      .map(l => ({
        lineItemId: l.lineItemId, itemName: l.itemName, poQty: l.poQty,
        alreadyGrnQty: alreadyGrnQty(input.poId, l.lineItemId),
        grnQty: l.grnQty, rate: l.rate, grnTotal: l.grnQty * l.rate, details: l.details
      }));
    const grandTotal = lines.reduce((s, l) => s + l.grnTotal, 0);
    const grn: VendorGrn = {
      id: 'GRN-' + pad(counters.current.vgrn++, 8),
      poId: po.id, poNumber: po.poNumber,
      grnDate: new Date().toISOString(),
      grandTotal,
      grandTotalLocal: Math.round(grandTotal * po.exchangeRate),
      lines, status: 'PENDING_APPROVAL', createdBy: input.createdBy
    };
    setVendorGrns2(l => [grn, ...l]);
    logAudit('GRN_GENERATED', 'GRN', grn.id, `GRN ${grn.id} entered against ${po.poNumber} for ${lines.length} line item(s), grand total ${grandTotal.toLocaleString()} ${po.poCurrency}. Awaiting approval.`, input.createdBy);
    const fullyReceived = po.lineItems.every(li => remainingQty(po.id, li.id) <= 0);
    const anyReceived = po.lineItems.some(li => alreadyGrnQty(po.id, li.id) > 0);
    const status: VendorPoStatus = fullyReceived ? 'COMPLETED' : anyReceived ? 'PARTIALLY_RECEIVED' : 'PENDING';
    setVendorPOs2(list => list.map(p => p.id === po.id ? { ...p, status } : p));
    return grn;
  }

  function approveVendorGrn(grnId: string, approver: string): void {
    const grn = vendorGrnsRef.current.find(g => g.id === grnId);
    if (!grn) return;
    setVendorGrns2(list => list.map(g => g.id === grnId ? { ...g, status: 'APPROVED', approvedBy: approver, approvedAt: new Date().toISOString() } : g));
    logAudit('GRN_GENERATED', 'GRN', grnId, `GRN ${grnId} approved by ${approver}. Assets registered in CMDB with lease terms.`, approver);
    const po = vendorPo(grn.poId);
    const newAssets: AssetRecord[] = [];
    for (const line of grn.lines) {
      const serials = line.details.serialNumbers.length ? line.details.serialNumbers
        : Array.from({ length: line.grnQty }).map(() => 'SN' + Math.random().toString(36).slice(2, 10).toUpperCase());
      serials.forEach(serialNumber => {
        const assetId = 'AST-' + pad(counters.current.ast++, 6);
        newAssets.push({
          assetId, serialNumber, deviceType: 'Laptop',
          vendor: (po?.vendorName as VendorName) ?? 'HP',
          model: line.itemName, catalogItemId: line.lineItemId,
          leaseStartDate: line.details.leaseStart, leaseEndDate: line.details.leaseEnd,
          cost: line.rate, location: 'Cognizant Warehouse',
          shipmentStatus: 'DELIVERED', lifecycleStatus: 'IN_STOCK',
          poId: grn.poId, grnId: grn.id, contract: grn.id
        });
      });
    }
    if (newAssets.length) {
      setAssets2(l => [...newAssets, ...l]);
      logAudit('ASSET_CREATED', 'Asset', newAssets.map(a => a.assetId).join(', '), `${newAssets.length} asset(s) registered from approved GRN ${grnId}.`, approver);
    }
  }

  function rejectVendorGrn(grnId: string, approver: string, reason: string): void {
    setVendorGrns2(list => list.map(g => g.id === grnId ? { ...g, status: 'REJECTED', rejectedBy: approver, rejectedReason: reason } : g));
    logAudit('GRN_GENERATED', 'GRN', grnId, `GRN ${grnId} rejected by ${approver}. Reason: ${reason}`, approver);
    const grn = vendorGrnsRef.current.find(g => g.id === grnId);
    if (grn) {
      const po = vendorPo(grn.poId);
      if (po) {
        const anyReceived = po.lineItems.some(li => alreadyGrnQty(po.id, li.id) > 0);
        setVendorPOs2(list => list.map(p => p.id === po.id ? { ...p, status: anyReceived ? 'PARTIALLY_RECEIVED' : 'PENDING' } : p));
      }
    }
  }

  // ── Finance ────────────────────────────────────────────────────────────────
  function submitInvoice(input: Omit<VendorInvoice, 'id' | 'status' | 'matchResult'>): VendorInvoice {
    const grn = input.grnId ? goodsReceipts.find(g => g.id === input.grnId) : undefined;
    const po = posRef.current.find(p => p.id === input.poId);
    const poMatch = !!po; const podMatch = !!grn?.podDataUrl || !!grn?.podFileName; const grnMatch = !!grn;
    const status: VendorInvoice['status'] = (poMatch && podMatch && grnMatch) ? 'MATCHED' : 'EXCEPTION';
    const invoice: VendorInvoice = {
      ...input,
      id: 'INV-' + input.vendor.toUpperCase() + '-' + pad(counters.current.inv++, 5),
      status,
      matchResult: { poMatch, podMatch, grnMatch, variance: status === 'EXCEPTION' ? 'Missing supporting document(s) for 3-way match.' : undefined }
    };
    setInvoices2(l => [invoice, ...l]);
    logAudit('INVOICE_SUBMITTED', 'Invoice', invoice.id, `${invoice.vendor} invoice submitted for ${invoice.amount.toLocaleString()} against ${invoice.poId}.`);
    logAudit(status === 'MATCHED' ? 'INVOICE_MATCHED' : 'INVOICE_EXCEPTION', 'Invoice', invoice.id, status === 'MATCHED' ? '3-way match successful (PO / POD / GRN).' : 'Exception raised during 3-way match validation.');
    return invoice;
  }

  function approveInvoicePayment(invoiceId: string, approver: string): void {
    setInvoices2(list => list.map(i => i.id === invoiceId ? { ...i, status: 'APPROVED_FOR_PAYMENT' } : i));
    logAudit('PAYMENT_APPROVED', 'Invoice', invoiceId, `Payment approved by ${approver}.`, approver);
  }

  function markInvoicePaid(invoiceId: string): void {
    setInvoices2(list => list.map(i => i.id === invoiceId ? { ...i, status: 'PAID' } : i));
  }

  function createLeaseSchedule(input: Omit<LeaseSchedule, 'id' | 'status'>): LeaseSchedule {
    const ls: LeaseSchedule = { ...input, id: 'LS-' + input.vendor.toUpperCase() + '-2026-' + pad(counters.current.ls++, 3), status: 'PENDING' };
    setLeaseSchedules(l => [ls, ...l]);
    setInvoices2(list => list.map(i => i.id === input.invoiceId ? { ...i, leaseScheduleId: ls.id } : i));
    logAudit('LEASE_SCHEDULE_CREATED', 'Lease', ls.id, `Lease schedule created: ${ls.termMonths} months @ ${ls.monthlyPayment}/mo.`);
    const invoice = invoicesRef.current.find(i => i.id === input.invoiceId);
    if (invoice) setAssets2(list => list.map(a => a.poId === invoice.poId ? { ...a, leaseStartDate: ls.startDate, leaseEndDate: ls.endDate, contract: ls.id } : a));
    return ls;
  }

  // ── Inventory ──────────────────────────────────────────────────────────────
  function assignAsset(assetId: string, user: string, location: string): void {
    setAssets2(list => list.map(a => a.assetId === assetId ? { ...a, assignedUser: user, location, lifecycleStatus: 'DEPLOYED' } : a));
    logAudit('ASSET_ASSIGNED', 'Asset', assetId, `Assigned to ${user} at ${location}.`);
  }

  function retireAsset(assetId: string): void {
    setAssets2(list => list.map(a => a.assetId === assetId ? { ...a, lifecycleStatus: 'RETIRED' } : a));
    logAudit('ASSET_RETIRED', 'Asset', assetId, `Asset retired from active service.`);
  }

  // ── Catalog ────────────────────────────────────────────────────────────────
  function upsertCatalogItem(item: CatalogItem, isNew: boolean): void {
    const next = isNew ? [item, ...catalogRef.current] : catalogRef.current.map(c => c.id === item.id ? item : c);
    catalogRef.current = next;
    setCatalog(next);
    logAudit(isNew ? 'CATALOG_ITEM_CREATED' : 'CATALOG_ITEM_UPDATED', 'Catalog', item.id, `${item.name}`);
  }

  // ── Seed ─────────────────────────────────────────────────────────────────
  const seeded = useRef(false);
  if (!seeded.current) {
    seeded.current = true;

    catalogRef.current = SEED_CATALOG;
    setCatalog(SEED_CATALOG);

    // Initial warehouse stock
    const stockAssets: AssetRecord[] = [
      ...Array.from({ length: 20 }).map((_, i) => ({
        assetId: 'AST-' + pad(counters.current.ast++, 6),
        serialNumber: 'SN-HP-CONV-' + pad(i + 1, 4),
        deviceType: 'Laptop' as const, vendor: 'HP' as VendorName,
        model: 'HP EliteBook X Flip G1i AI', catalogItemId: 'CAT-CONV',
        cost: 1540, location: 'Cognizant Warehouse',
        shipmentStatus: 'DELIVERED' as const, lifecycleStatus: 'IN_STOCK' as const,
        poId: 'PO-2026-00099', vendorOrderId: 'VO-2026-00050', grnId: 'GRN-2026-00050'
      })),
      ...Array.from({ length: 10 }).map((_, i) => ({
        assetId: 'AST-' + pad(counters.current.ast++, 6),
        serialNumber: 'SN-HP-14STD-' + pad(i + 1, 4),
        deviceType: 'Laptop' as const, vendor: 'HP' as VendorName,
        model: 'HP EliteBook 8 G1i 14 AI', catalogItemId: 'CAT-14STD',
        cost: 1420, location: 'Cognizant Warehouse',
        shipmentStatus: 'DELIVERED' as const, lifecycleStatus: 'IN_STOCK' as const,
        poId: 'PO-2026-00098', vendorOrderId: 'VO-2026-00049', grnId: 'GRN-2026-00049'
      })),
    ];
    assetsRef.current = stockAssets;
    setAssets(stockAssets);

    // Scenario 1: Happy-path delivered PO
    const po1: PurchaseOrder = { id: 'PO-2026-' + pad(counters.current.po++), clientName: 'Meridian Financial Group', poNumber: 'MFG-PO-88213', source: 'API', catalogItemId: 'CAT-CONV', quantity: 100, unitCost: 1540, status: 'PENDING_APPROVAL', submittedAt: new Date().toISOString(), requestId: 'REQ-2026-' + pad(counters.current.req++), notes: 'Refresh cycle FY26 - branch staff laptops.', acknowledgedAt: new Date().toISOString() };
    posRef.current = [po1];
    setPurchaseOrders([po1]);
    approvePO(po1.id, 'A. Subramanian (Cognizant)');
    const vo1 = createVendorOrder({ poId: po1.id, requestId: po1.requestId!, vendor: 'HP', vendorSku: 'C2ZK6EC', channel: 'Webshop Portal', quantity: 100, unitCost: 1540, destination: 'Cognizant Warehouse', catalogItemId: po1.catalogItemId });
    submitVendorOrder(vo1.id);
    advanceVendorOrderStatus(vo1.id, 'CONFIRMED', { confirmedAt: new Date().toISOString(), eta: '2026-08-20' });
    addShipmentEvent(vo1.id, 'LABEL_CREATED', 'HP Fulfillment Center, TX');
    addShipmentEvent(vo1.id, 'IN_TRANSIT', 'Memphis, TN', 'Carrier: FedEx Freight');
    addShipmentEvent(vo1.id, 'OUT_FOR_DELIVERY', 'Chennai Regional Hub');
    addShipmentEvent(vo1.id, 'DELIVERED', 'Cognizant Warehouse - Chennai');
    const grn1 = createGoodsReceipt({ vendorOrderId: vo1.id, poId: po1.id, quantityReceived: 100, quantityExpected: 100, receivedBy: 'Warehouse Ops - S. Iyer', podFileName: 'POD_HP_VO2026-00118.pdf', condition: 'Good' });
    const inv1 = submitInvoice({ vendor: 'HP', vendorOrderId: vo1.id, grnId: grn1.id, poId: po1.id, amount: 154000, currency: 'USD', invoiceDate: '2026-08-05', dueDate: '2026-09-04' });
    approveInvoicePayment(inv1.id, 'Finance - R. Nair');
    createLeaseSchedule({ vendor: 'HP', invoiceId: inv1.id, termMonths: 36, monthlyPayment: 4278, startDate: '2026-08-10', endDate: '2029-08-10' });
    assetsRef.current.slice(0, 3).map(a => a.assetId).forEach((id, i) => assignAsset(id, `Employee-${1000 + i}`, 'Chennai Branch Office'));

    // Scenario 2: Pending-approval PO
    const po2: PurchaseOrder = { id: 'PO-2026-' + pad(counters.current.po++), clientName: 'Meridian Financial Group', poNumber: 'MFG-PO-88250', source: 'PDF_IMPORT', fileName: 'MFG_PO_88250.pdf', catalogItemId: 'CAT-14STD', quantity: 40, unitCost: 1585, status: 'PENDING_APPROVAL', submittedAt: new Date().toISOString(), requestId: 'REQ-2026-' + pad(counters.current.req++), notes: 'New hire cohort - Q4.', acknowledgedAt: new Date().toISOString() };
    setPOs2(l => [po2, ...l]);

    // Scenario 3: On-order vendor order
    const po3: PurchaseOrder = { id: 'PO-2026-' + pad(counters.current.po++), clientName: 'Meridian Financial Group', poNumber: 'MFG-PO-88199', source: 'API', catalogItemId: 'CAT-14STD', quantity: 15, unitCost: 1585, status: 'PENDING_APPROVAL', submittedAt: new Date().toISOString(), requestId: 'REQ-2026-' + pad(counters.current.req++), notes: 'Early pilot batch.', acknowledgedAt: new Date().toISOString() };
    setPOs2(l => [po3, ...l]);
    approvePO(po3.id, 'A. Subramanian (Cognizant)');
    const vo3 = createVendorOrder({ poId: po3.id, requestId: po3.requestId!, vendor: 'HP', vendorSku: 'C2ZK6EC', channel: 'Webshop Portal', quantity: 15, unitCost: 1585, destination: 'Cognizant Warehouse', catalogItemId: po3.catalogItemId });
    submitVendorOrder(vo3.id);
    advanceVendorOrderStatus(vo3.id, 'CONFIRMED', { confirmedAt: new Date().toISOString(), eta: '2026-08-25' });

    // Scenario 4: Approved PR
    const po4: PurchaseOrder = { id: 'PO-2026-' + pad(counters.current.po++), clientName: 'Meridian Financial Group', poNumber: 'MFG-PO-88301', source: 'API', catalogItemId: 'CAT-CONV', quantity: 50, unitCost: 1540, status: 'PENDING_APPROVAL', submittedAt: new Date().toISOString(), requestId: 'REQ-2026-' + pad(counters.current.req++), notes: 'Q3 expansion.', acknowledgedAt: new Date().toISOString() };
    setPOs2(l => [po4, ...l]);
    approvePO(po4.id, 'A. Subramanian (Cognizant)');
    const pr4 = createPurchaseRequisition({ poId: po4.id, requestedQty: 50, preferredVendor: 'HP', estimatedUnitCost: 1540, costCenter: 'CC-APAC-IT-01', justification: 'Q3 laptop refresh for Chennai branch expansion.', requestedBy: 'S. Krishnamurthy' });
    emailPrForApproval(pr4.id, 'a.subramanian@cognizant.com');
    submitPrForApproval(pr4.id);
    approvePr(pr4.id, 'A. Subramanian (Cognizant)');

    // Scenario 5: Pending-approval PR
    const po5: PurchaseOrder = { id: 'PO-2026-' + pad(counters.current.po++), clientName: 'Meridian Financial Group', poNumber: 'MFG-PO-88310', source: 'API', catalogItemId: 'CAT-14STD', quantity: 25, unitCost: 1585, status: 'PENDING_APPROVAL', submittedAt: new Date().toISOString(), requestId: 'REQ-2026-' + pad(counters.current.req++), notes: 'Finance team laptop upgrade.', acknowledgedAt: new Date().toISOString() };
    setPOs2(l => [po5, ...l]);
    approvePO(po5.id, 'A. Subramanian (Cognizant)');
    const pr5 = createPurchaseRequisition({ poId: po5.id, requestedQty: 25, preferredVendor: 'Dell', estimatedUnitCost: 1585, costCenter: 'CC-FIN-02', justification: 'Finance team annual device refresh.', requestedBy: 'R. Nair' });
    emailPrForApproval(pr5.id, 'a.subramanian@cognizant.com');
    submitPrForApproval(pr5.id);

    // Vendor PO seed data
    const vendorPos: VendorPurchaseOrder[] = [
      {
        id: 'PO-2024-005', poNumber: 'PO-2024-005', poDate: '2024-05-18',
        vendorName: 'NOVATEUR E&DS PVT.LTD. UPS DIV. SW',
        poCurrency: 'Dollar', localCurrency: 'Chinese Yuan', exchangeRate: 7.18,
        poValue: 1300000, status: 'PENDING',
        lineItems: [
          { id: 'PO24005-L1', itemName: 'DELL LATITUDE 5450 XCTO BASE B6JFR44', poQty: 1000, rate: 700 },
          { id: 'PO24005-L2', itemName: 'OPTIPLEX MICRO FORM FACTOR 7020 CM8DM24', poQty: 1200, rate: 300 },
          { id: 'PO24005-L3', itemName: 'PERFORMANCE INSIGHTS & ANALYTIC SOLUTION', poQty: 2000, rate: 120 },
        ]
      },
      {
        id: 'PO-2024-002', poNumber: 'PO-2024-002', poDate: '2024-02-10',
        vendorName: 'THE GRAND AFFAIR',
        poCurrency: 'Dollar', localCurrency: 'Indian Rupee', exchangeRate: 83.2,
        poValue: 145000, status: 'PENDING',
        lineItems: [{ id: 'PO24002-L1', itemName: 'EVENT AV & STAGING SERVICES', poQty: 50, rate: 2900 }]
      },
      {
        id: 'PO-2024-004', poNumber: 'PO-2024-004', poDate: '2024-04-12',
        vendorName: 'NOVATEUR E&DS PVT.LTD. UPS DIV. SW',
        poCurrency: 'Dollar', localCurrency: 'Chinese Yuan', exchangeRate: 7.18,
        poValue: 130000, status: 'PENDING',
        lineItems: [{ id: 'PO24004-L1', itemName: 'UPS 3KVA ONLINE MODULAR RACKMOUNT', poQty: 260, rate: 500 }]
      },
    ];
    vendorPOsRef.current = vendorPos;
    setVendorPOs(vendorPos);

    // Seed one previous GRN
    createVendorGrn({
      poId: 'PO-2024-005', createdBy: 'Sandeep Lacheta',
      lines: [
        { lineItemId: 'PO24005-L1', itemName: 'DELL LATITUDE 5450 XCTO BASE B6JFR44', poQty: 1000, grnQty: 20, rate: 700, details: { serialNumbers: Array.from({ length: 20 }).map((_, i) => 'SN-DELL5450-' + pad(i + 1, 4)), leaseStart: '2026-10-01', leaseEnd: '2031-09-30' } },
        { lineItemId: 'PO24005-L2', itemName: 'OPTIPLEX MICRO FORM FACTOR 7020 CM8DM24', poQty: 1200, grnQty: 10, rate: 300, details: { serialNumbers: Array.from({ length: 10 }).map((_, i) => 'SN-OPTX7020-' + pad(i + 1, 4)), leaseStart: '2026-10-01', leaseEnd: '2031-09-30' } }
      ]
    });
  }

  // ── Derived stats ─────────────────────────────────────────────────────────
  const dashboardStats = useMemo(() => ({
    totalPOs: purchaseOrders.length,
    pendingApproval: purchaseOrders.filter(p => p.status === 'PENDING_APPROVAL' || p.status === 'ACKNOWLEDGED').length,
    approved: purchaseOrders.filter(p => p.status === 'APPROVED').length,
    inProcurement: vendorOrders.filter(v => v.status === 'SUBMITTED' || v.status === 'CONFIRMED' || v.status === 'IN_PRODUCTION').length,
    inTransit: vendorOrders.filter(v => v.status === 'SHIPPED').length,
    delivered: vendorOrders.filter(v => v.status === 'DELIVERED').length,
    invoiceExceptions: invoices.filter(i => i.status === 'EXCEPTION').length,
    totalAssets: assets.length,
    deployedAssets: assets.filter(a => a.lifecycleStatus === 'DEPLOYED').length,
    totalDevicesRequested: purchaseOrders.reduce((s, p) => s + p.quantity, 0),
    pendingPrApprovals: purchaseRequisitions.filter(pr => pr.status === 'PENDING_APPROVAL').length,
    unreadNotifications: notifications.filter(n => !n.read).length,
  }), [purchaseOrders, purchaseRequisitions, vendorOrders, invoices, assets, notifications]);

  const auditFor = useCallback((entityId: string) => auditLog.filter(a => a.entityId === entityId), [auditLog]);
  const markNotificationRead = useCallback((id: string) => setNotifs2(l => l.map(n => n.id === id ? { ...n, read: true } : n)), []);
  const markAllNotificationsRead = useCallback(() => setNotifs2(l => l.map(n => ({ ...n, read: true }))), []);

  const value: DataContextValue = {
    purchaseOrders, purchaseRequisitions, vendorOrders, goodsReceipts,
    invoices, leaseSchedules, assets, auditLog, catalog,
    vendorPurchaseOrders, vendorGrns, notifications, dashboardStats,
    auditFor, markNotificationRead, markAllNotificationsRead,
    intakePO, approvePO, rejectPO,
    availableWarehouseStock, onOrderQuantity, fulfillFromWarehouse,
    createPurchaseRequisition, submitPrForApproval, emailPrForApproval, approvePr, rejectPr, markPrConverted,
    createVendorOrder, submitVendorOrder, advanceVendorOrderStatus, addShipmentEvent,
    createGoodsReceipt,
    vendorPo, grnsForPo, alreadyGrnQty, remainingQty, createVendorGrn, approveVendorGrn, rejectVendorGrn,
    submitInvoice, approveInvoicePayment, markInvoicePaid, createLeaseSchedule,
    assignAsset, retireAsset,
    upsertCatalogItem,
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}
