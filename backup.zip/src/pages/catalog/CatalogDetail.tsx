import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import type { CatalogItem, CatalogCategory, ServiceClass } from '../../types/models';
import { MODEL_CATEGORIES, SERVICE_CLASSES } from '../../types/models';

export default function CatalogDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { catalog, upsertCatalogItem } = useData();

  const isNew = id === 'new';
  const existing = catalog.find(c => c.id === id);

  const blank: CatalogItem = {
    id: '', category: 'HW - DaaS Laptop', name: '', screenSize: '', touch: false, ramGb: 16, storageGb: 1000, cpu: '',
    clientListPrice: 0, active: true, region: '', country: '', clientCategory: '', persona: '',
    shopDescription: '', longDescription: '', detailedDescription: '', keywords: '',
    modelCategory: '14" Standard Notebook', eolTimeline: '',
    currentGenModel: '', currentGenSku: '', currentGenConfigDetails: '',
    newGenModel: '', newGenSku: '', newGenConfigDetails: '',
    serviceClass: 'DaaS Standard', reportingHierarchy: 'HW > Laptops > DaaS', vendorMappings: [],
  };

  const [form, setForm] = useState<CatalogItem>(existing ?? blank);
  const [saved, setSaved] = useState(false);

  useEffect(() => { if (existing) setForm(existing); }, [existing?.id]);

  if (!isNew && !existing) return <div className="text-slate-500 p-8">Catalog item not found.</div>;

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    const item = { ...form, id: isNew ? ('CAT-' + form.name.slice(0, 6).replace(/\s/g, '-').toUpperCase() + '-' + Date.now().toString(36).slice(-4)) : form.id };
    upsertCatalogItem(item, isNew);
    setSaved(true);
    setTimeout(() => navigate('/catalog'), 600);
  }

  const f = form;
  const set = (patch: Partial<CatalogItem>) => setForm(prev => ({ ...prev, ...patch }));

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <button onClick={() => navigate('/catalog')} className="text-sm text-brand-600 hover:underline mb-2 flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
          Back to Catalog
        </button>
        <h1 className="text-2xl font-bold text-slate-900">{isNew ? 'Add Catalog Item' : f.name}</h1>
      </div>

      <form onSubmit={handleSave} className="space-y-5">
        {/* Core */}
        <div className="a360-card p-5 space-y-4">
          <h3 className="font-semibold text-slate-700">Core Details</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2"><label className="a360-label">Name *</label><input value={f.name} onChange={e => set({ name: e.target.value })} className="a360-input" required /></div>
            <div><label className="a360-label">Category</label>
              <select value={f.category} onChange={e => set({ category: e.target.value as CatalogCategory })} className="a360-input">
                <option>HW - DaaS Laptop</option><option>HW - DaaS Desktop</option><option>HW - Monitor</option>
              </select>
            </div>
            <div><label className="a360-label">Service Class</label>
              <select value={f.serviceClass} onChange={e => set({ serviceClass: e.target.value as ServiceClass })} className="a360-input">
                {SERVICE_CLASSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div><label className="a360-label">Screen Size</label><input value={f.screenSize} onChange={e => set({ screenSize: e.target.value })} className="a360-input" /></div>
            <div><label className="a360-label">CPU</label><input value={f.cpu} onChange={e => set({ cpu: e.target.value })} className="a360-input" /></div>
            <div><label className="a360-label">RAM (GB)</label><input type="number" value={f.ramGb} onChange={e => set({ ramGb: parseInt(e.target.value) })} className="a360-input" /></div>
            <div><label className="a360-label">Storage (GB)</label><input type="number" value={f.storageGb} onChange={e => set({ storageGb: parseInt(e.target.value) })} className="a360-input" /></div>
            <div><label className="a360-label">List Price (USD)</label><input type="number" value={f.clientListPrice} onChange={e => set({ clientListPrice: parseFloat(e.target.value) })} className="a360-input" /></div>
            <div className="flex items-end pb-1"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={f.touch} onChange={e => set({ touch: e.target.checked })} className="rounded" /><span className="a360-label mb-0">Touch Screen</span></label></div>
            <div className="flex items-end pb-1"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={f.active} onChange={e => set({ active: e.target.checked })} className="rounded" /><span className="a360-label mb-0">Active</span></label></div>
          </div>
        </div>

        {/* Vendor / Model */}
        <div className="a360-card p-5 space-y-4">
          <h3 className="font-semibold text-slate-700">Current Gen Model</h3>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="a360-label">Model</label><input value={f.currentGenModel} onChange={e => set({ currentGenModel: e.target.value })} className="a360-input" /></div>
            <div><label className="a360-label">SKU</label><input value={f.currentGenSku} onChange={e => set({ currentGenSku: e.target.value })} className="a360-input" /></div>
            <div className="col-span-2"><label className="a360-label">Config Details</label><input value={f.currentGenConfigDetails} onChange={e => set({ currentGenConfigDetails: e.target.value })} className="a360-input" /></div>
            <div><label className="a360-label">New Gen Model</label><input value={f.newGenModel} onChange={e => set({ newGenModel: e.target.value })} className="a360-input" /></div>
            <div><label className="a360-label">New Gen SKU</label><input value={f.newGenSku} onChange={e => set({ newGenSku: e.target.value })} className="a360-input" /></div>
            <div><label className="a360-label">Model Category</label>
              <select value={f.modelCategory} onChange={e => set({ modelCategory: e.target.value as typeof f.modelCategory })} className="a360-input">
                {MODEL_CATEGORIES.map(m => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div><label className="a360-label">EOL Timeline</label><input value={f.eolTimeline} onChange={e => set({ eolTimeline: e.target.value })} className="a360-input" /></div>
          </div>
        </div>

        <div className="flex gap-2">
          <button type="submit" disabled={saved} className="a360-btn-primary">{saved ? 'Saved!' : isNew ? 'Add to Catalog' : 'Save Changes'}</button>
          <button type="button" onClick={() => navigate('/catalog')} className="a360-btn-secondary">Cancel</button>
        </div>
      </form>
    </div>
  );
}
