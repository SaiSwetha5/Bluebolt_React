import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import type { CatalogCategory } from '../../types/models';

const CATEGORIES: (CatalogCategory | 'ALL')[] = ['ALL', 'HW - DaaS Laptop', 'HW - DaaS Desktop', 'HW - Monitor'];

export default function CatalogList() {
  const { catalog } = useData();
  const navigate = useNavigate();
  const [cat, setCat] = useState<CatalogCategory | 'ALL'>('ALL');
  const [search, setSearch] = useState('');

  const filtered = catalog
    .filter(c => cat === 'ALL' || c.category === cat)
    .filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.currentGenModel.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Device Catalog</h1>
          <p className="text-slate-500 text-sm">{catalog.length} catalog items</p>
        </div>
        <button onClick={() => navigate('/catalog/new')} className="a360-btn-primary">+ Add Item</button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
          {CATEGORIES.map(c => (
            <button key={c} onClick={() => setCat(c)} className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${cat === c ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600 hover:text-slate-900'}`}>
              {c === 'ALL' ? 'All' : c.replace('HW - ', '')}
            </button>
          ))}
        </div>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name or model…" className="a360-input max-w-xs" />
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item => (
          <div key={item.id} className="a360-card p-5 cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate(`/catalog/${item.id}`)}>
            <div className="flex items-start justify-between gap-2 mb-3">
              <div>
                <p className="font-semibold text-slate-800 text-sm leading-tight">{item.name}</p>
                <p className="text-xs text-slate-500 mt-1">{item.category}</p>
              </div>
              <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-semibold flex-shrink-0 ${item.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                {item.active ? 'Active' : 'Inactive'}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center border-t border-slate-100 pt-3">
              <div><p className="text-xs text-slate-400">RAM</p><p className="text-sm font-semibold">{item.ramGb}GB</p></div>
              <div><p className="text-xs text-slate-400">Storage</p><p className="text-sm font-semibold">{item.storageGb}GB</p></div>
              <div><p className="text-xs text-slate-400">List Price</p><p className="text-sm font-semibold">${item.clientListPrice.toLocaleString()}</p></div>
            </div>
            <p className="text-xs text-slate-500 mt-3 truncate">{item.currentGenModel} · {item.currentGenSku}</p>
            <div className="flex flex-wrap gap-1 mt-2">
              {item.vendorMappings.map(m => (
                <span key={m.vendor} className="text-xs bg-brand-50 text-brand-700 px-1.5 py-0.5 rounded">{m.vendor}</span>
              ))}
              <span className="text-xs bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">{item.serviceClass}</span>
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div className="col-span-3 text-center text-slate-400 py-8">No catalog items found.</div>}
      </div>
    </div>
  );
}
