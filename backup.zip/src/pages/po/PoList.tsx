import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';
import type { PoStatus } from '../../types/models';

const TABS: { label: string; filter: PoStatus | 'ALL' }[] = [
  { label: 'All', filter: 'ALL' },
  { label: 'Pending Approval', filter: 'PENDING_APPROVAL' },
  { label: 'Approved', filter: 'APPROVED' },
  { label: 'Rejected', filter: 'REJECTED' },
];

export default function PoList() {
  const { purchaseOrders, catalog } = useData();
  const navigate = useNavigate();
  const [tab, setTab] = useState<PoStatus | 'ALL'>('ALL');
  const [search, setSearch] = useState('');

  const filtered = purchaseOrders
    .filter(po => tab === 'ALL' || po.status === tab)
    .filter(po => !search || po.poNumber.toLowerCase().includes(search.toLowerCase()) || po.clientName.toLowerCase().includes(search.toLowerCase()));

  const getCatalogName = (id: string) => catalog.find(c => c.id === id)?.name ?? id;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Purchase Orders</h1>
          <p className="mt-1 text-sm text-slate-500">{purchaseOrders.length} total orders</p>
        </div>
        <button onClick={() => navigate('/po/import')} className="a360-btn-primary">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
         New Customer Po Intake 
        </button>
      </div>

      {/* Tabs + Search */}
      <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center">
        <div className="flex gap-1 p-1 rounded-lg bg-slate-100">
          {TABS.map(t => (
            <button key={t.filter} onClick={() => setTab(t.filter)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${tab === t.filter ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600 hover:text-slate-900'}`}>
              {t.label}
            </button>
          ))}
        </div>
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search PO number or client…"
          className="max-w-xs a360-input"
        />
      </div>

      <div className="overflow-hidden a360-card">
        <table className="w-full">
          <thead>
            <tr>
              <th className="a360-th">PO ID</th>
              <th className="a360-th">Client</th>
              <th className="a360-th">PO Number</th>
              <th className="a360-th">Device</th>
              <th className="a360-th">Qty</th>
              <th className="a360-th">Unit Cost</th>
              <th className="a360-th">Source</th>
              <th className="a360-th">Submitted</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={9} className="py-8 text-center a360-td text-slate-400">No purchase orders found.</td></tr>
            )}
            {filtered.map(po => (
              <tr key={po.id} className="cursor-pointer hover:bg-slate-50" onClick={() => navigate(`/po/${po.id}`)}>
                <td className="font-mono text-xs a360-td text-brand-600">{po.id}</td>
                <td className="font-medium a360-td">{po.clientName}</td>
                <td className="font-mono text-xs a360-td">{po.poNumber}</td>
                <td className="max-w-xs text-xs truncate a360-td">{getCatalogName(po.catalogItemId)}</td>
                <td className="a360-td">{po.quantity}</td>
                <td className="a360-td">${po.unitCost.toLocaleString()}</td>
                <td className="a360-td">
                  <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded">{po.source}</span>
                </td>
                <td className="text-xs a360-td">{new Date(po.submittedAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      
    </div>
  );
}
