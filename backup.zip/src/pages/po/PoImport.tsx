import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import type { CatalogItem } from '../../types/models';

type Tab = 'api' | 'pdf';
type PdfStep = 'upload' | 'extracting' | 'review';

interface ExtractedPO {
  clientName: string;
  poNumber: string;
  catalogItemId: string;
  rawItemDescription: string;
  quantity: string;
  unitCost: string;
  notes: string;
}

// ── PDF text extraction via pdfjs-dist ────────────────────────────────────────
async function extractTextFromPdf(arrayBuffer: ArrayBuffer): Promise<string> {
  // Dynamically import to avoid top-level issues with the worker
  const pdfjsLib = await import('pdfjs-dist');
  // Use the bundled legacy worker that ships with pdfjs-dist
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.mjs',
    import.meta.url,
  ).toString();

  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  const pages: string[] = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    pages.push(content.items.map((it: { str?: string }) => it.str ?? '').join(' '));
  }
  return pages.join('\n');
}

// ── Field extraction helpers ───────────────────────────────────────────────────
function extractField(text: string, ...patterns: RegExp[]): string {
  for (const re of patterns) {
    const m = text.match(re);
    if (m?.[1]?.trim()) return m[1].trim();
  }
  return '';
}

function parseExtractedPO(rawText: string, activeCatalog: CatalogItem[]): ExtractedPO {
  // Normalise whitespace
  const t = rawText.replace(/\s+/g, ' ');

  // ── Client name ──────────────────────────────────────────────────────────
  const clientName = extractField(t,
    /Client\s*Name[:\s]+([^\n|,]+?)(?=\s*(?:PO|Purchase|Client|$))/i,
    /Bill[\s-]*To[:\s]+([^\n|,]+)/i,
    /Buyer[:\s]+([^\n|,]+)/i,
    /Company[:\s]+([^\n|,]+)/i,
  );

  // ── PO number ────────────────────────────────────────────────────────────
  const poNumber = extractField(t,
    /(?:Client\s+)?PO\s*(?:Number|No\.?|#)[:\s]+([A-Z0-9][-A-Z0-9_/]+)/i,
    /Purchase\s*Order\s*(?:Number|No\.?|#)[:\s]+([A-Z0-9][-A-Z0-9_/]+)/i,
    /Order\s*(?:Number|No\.?|#)[:\s]+([A-Z0-9][-A-Z0-9_/]+)/i,
    /\b([A-Z]{2,}-PO-\d+)\b/i,
    /\b(PO[-\s]?\d{4,})\b/i,
  );

  // ── Quantity ─────────────────────────────────────────────────────────────
  const qtyRaw = extractField(t,
    /Quantity[:\s]+(\d[\d,]*)/i,
    /Qty[:\s]+(\d[\d,]*)/i,
    /Units?[:\s]+(\d[\d,]*)/i,
    /No\.?\s*of\s*(?:Units?|Items?)[:\s]+(\d[\d,]*)/i,
  );
  const quantity = qtyRaw.replace(/,/g, '');

  // ── Unit cost ────────────────────────────────────────────────────────────
  const unitCostRaw = extractField(t,
    /Unit\s*(?:Price|Cost)[:\s]+[\$USD]*\s*([\d,]+(?:\.\d{1,2})?)/i,
    /Price\s*per\s*(?:unit|item)[:\s]+[\$USD]*\s*([\d,]+(?:\.\d{1,2})?)/i,
    /Rate[:\s]+[\$USD]*\s*([\d,]+(?:\.\d{1,2})?)/i,
  );
  const unitCost = unitCostRaw.replace(/,/g, '');

  // ── Notes ────────────────────────────────────────────────────────────────
  const notes = extractField(t,
    /Notes?[:\s]+(.+?)(?=\n|Expected|$)/i,
    /(?:Special\s+)?Instructions?[:\s]+(.+?)(?=\n|Expected|$)/i,
    /Remarks?[:\s]+(.+?)(?=\n|Expected|$)/i,
    /Delivery\s+(?:Notes?|Instructions?)[:\s]+(.+?)(?=\n|Expected|$)/i,
  );

  // ── Catalog item match ────────────────────────────────────────────────────
  // First try to extract the item description from common PDF field labels
  const rawItemDescription = extractField(t,
    /Catalog\s*Item[:\s]+([^\n|]+)/i,
    /Device\s*(?:Model|Type)[:\s]+([^\n|]+)/i,
    /Item\s*(?:Description|Name)[:\s]+([^\n|]+)/i,
    /Product[:\s]+([^\n|]+)/i,
    /Model[:\s]+([^\n|]+)/i,
    /SKU[:\s]+([^\n|]+)/i,
  );

  // Score each catalog item against both the raw description and the full PDF text
  const catalogItemId = bestCatalogMatch(rawItemDescription || t, t, activeCatalog);

  return { clientName, poNumber, catalogItemId, rawItemDescription, quantity, unitCost, notes };
}

// ── Fuzzy catalog matcher ─────────────────────────────────────────────────────
function bestCatalogMatch(primary: string, fullText: string, catalog: CatalogItem[]): string {
  const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  const p = norm(primary);
  const f = norm(fullText);

  let bestId = '';
  let bestScore = 0;

  for (const item of catalog) {
    // Build a set of searchable strings for this catalog item
    const haystack = [
      item.name,
      item.shopDescription,
      item.currentGenModel,
      item.newGenModel,
      item.currentGenSku,
      item.newGenSku,
      item.longDescription,
      item.modelCategory,
      item.cpu,
      ...item.vendorMappings.map(v => `${v.vendor} ${v.currentGenModel} ${v.currentGenSku} ${v.newGenModel}`),
    ].map(norm).join(' | ');

    // Token overlap score: how many words from the haystack appear in the search text
    const haystackTokens = new Set(haystack.split(/[\s|]+/).filter(w => w.length > 2));
    let score = 0;
    for (const token of haystackTokens) {
      if (p.includes(token)) score += 3;      // primary description match weighs more
      else if (f.includes(token)) score += 1; // full-text fallback
    }

    // Boost for brand mentions
    const brands = ['hp', 'dell', 'lenovo'];
    for (const brand of brands) {
      if (haystack.includes(brand) && (p.includes(brand) || f.includes(brand))) score += 2;
    }

    // Boost for numeric specs found in both
    const specPattern = /\b(\d+(?:gb|tb|ghz|inch|"|core))\b/gi;
    const haystackSpecs = [...haystack.matchAll(specPattern)].map(m => m[1].toLowerCase());
    const primarySpecs  = [...(p + ' ' + f).matchAll(specPattern)].map(m => m[1].toLowerCase());
    for (const spec of haystackSpecs) {
      if (primarySpecs.includes(spec)) score += 2;
    }

    if (score > bestScore) {
      bestScore = score;
      bestId = item.id;
    }
  }

  // Only return a match if we have reasonable confidence
  return bestScore >= 3 ? bestId : '';
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function PoImport() {
  const { intakePO, catalog } = useData();
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);

  const [activeTab, setActiveTab] = useState<Tab>('api');

  // API tab state
  const [form, setForm] = useState({
    clientName: '', poNumber: '', catalogItemId: '', quantity: '100', unitCost: '', notes: ''
  });
  const [apiSubmitted, setApiSubmitted] = useState(false);

  // PDF tab state
  const [fileName, setFileName] = useState('');
  const [fileDataUrl, setFileDataUrl] = useState('');
  const [pdfStep, setPdfStep] = useState<PdfStep>('upload');
  const [extractError, setExtractError] = useState('');
  const [extracted, setExtracted] = useState<ExtractedPO>({
    clientName: '', poNumber: '', catalogItemId: '', rawItemDescription: '',
    quantity: '', unitCost: '', notes: ''
  });
  const [pdfSubmitted, setPdfSubmitted] = useState(false);

  const activeCatalog = catalog.filter(c => c.active);

  // ── PDF upload + extraction ─────────────────────────────────────────────
  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setPdfStep('extracting');
    setExtractError('');

    try {
      // Read as both ArrayBuffer (for pdfjs) and DataURL (for storage)
      const [arrayBuffer, dataUrl] = await Promise.all([
        file.arrayBuffer(),
        new Promise<string>((resolve, reject) => {
          const r = new FileReader();
          r.onload = () => resolve(r.result as string);
          r.onerror = reject;
          r.readAsDataURL(file);
        }),
      ]);

      setFileDataUrl(dataUrl);

      const rawText = await extractTextFromPdf(arrayBuffer);
      const result = parseExtractedPO(rawText, activeCatalog);

      // Check if key fields were found
      const anyFound = result.clientName || result.poNumber || result.quantity;
      if (!anyFound) {
        setExtractError(
          'Could not read text from this PDF (it may be scanned/image-based). Please fill in the fields manually.'
        );
      } else if (!result.catalogItemId) {
        setExtractError(
          `Item "${result.rawItemDescription || 'in the PDF'}" could not be matched to an approved catalog item. Please select one manually.`
        );
      }

      setExtracted(result);
      setPdfStep('review');
    } catch (err) {
      console.error('PDF extraction error:', err);
      setExtractError('Failed to process the PDF file. Please fill in the fields manually.');
      setExtracted({
        clientName: '', poNumber: '', catalogItemId: '', rawItemDescription: '',
        quantity: '', unitCost: '', notes: ''
      });
      setPdfStep('review');
    }
  }

  // ── Submit handlers ─────────────────────────────────────────────────────
  function handleApiSubmit() {
    const po = intakePO({
      clientName: form.clientName,
      poNumber: form.poNumber,
      source: 'MANUAL',
      catalogItemId: form.catalogItemId,
      quantity: parseInt(form.quantity, 10),
      unitCost: parseFloat(form.unitCost) || 0,
      notes: form.notes,
    });
    setApiSubmitted(true);
    setTimeout(() => navigate(`/po/${po.id}`), 800);
  }

  function handlePdfSubmit() {
    const qty = parseInt(extracted.quantity, 10);
    const cost = parseFloat(extracted.unitCost);
    const catalogItem = activeCatalog.find(c => c.id === extracted.catalogItemId);
    const resolvedCost = Number.isFinite(cost) ? cost : (catalogItem?.clientListPrice ?? 0);

    const po = intakePO({
      clientName: extracted.clientName,
      poNumber: extracted.poNumber,
      source: 'PDF_IMPORT',
      catalogItemId: extracted.catalogItemId,
      quantity: Number.isFinite(qty) && qty > 0 ? qty : 1,
      unitCost: resolvedCost,
      notes: extracted.notes,
      fileName,
      fileDataUrl,
    });
    setPdfSubmitted(true);
    setTimeout(() => navigate(`/po/${po.id}`), 800);
  }

  function resetPdf() {
    setFileName('');
    setFileDataUrl('');
    setPdfStep('upload');
    setExtractError('');
    setPdfSubmitted(false);
    setExtracted({
      clientName: '', poNumber: '', catalogItemId: '', rawItemDescription: '',
      quantity: '', unitCost: '', notes: ''
    });
    if (fileRef.current) fileRef.current.value = '';
  }

  const canSubmitApi = form.clientName && form.poNumber && form.catalogItemId && form.quantity;
  const canSubmitPdf =
    extracted.clientName.trim() &&
    extracted.poNumber.trim() &&
    extracted.catalogItemId &&
    extracted.quantity.trim();

  // ── Render ──────────────────────────────────────────────────────────────
  return (
    <div className="max-w-2xl space-y-5">
      {/* Header */}
      <div>
        <button onClick={() => navigate('/po')} className="text-sm text-brand-600 hover:underline mb-2 flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
          </svg>
          Back to Customer POs
        </button>
        <h1 className="text-2xl font-bold text-slate-900">New Customer PO Intake</h1>
        <p className="text-slate-500 text-sm mt-1">
          Receive a purchase order directly via integration or import a PDF copy.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {(['api', 'pdf'] as Tab[]).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-2 rounded-md text-sm font-semibold transition-colors ${
              activeTab === tab
                ? 'bg-brand-600 text-white'
                : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {tab === 'api' ? 'Client API Integration' : 'PDF Import'}
          </button>
        ))}
      </div>

      {/* ── API tab ── */}
      {activeTab === 'api' && (
        <div className="a360-card p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="a360-label">CLIENT NAME</label>
              <input value={form.clientName} onChange={e => setForm(f => ({ ...f, clientName: e.target.value }))} className="a360-input" placeholder="Meridian Financial Group" />
            </div>
            <div>
              <label className="a360-label">CLIENT PO NUMBER</label>
              <input value={form.poNumber} onChange={e => setForm(f => ({ ...f, poNumber: e.target.value }))} className="a360-input" placeholder="e.g. MFG-PO-88301" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="a360-label">CATALOG ITEM <span className="text-red-500">*</span></label>
              <select value={form.catalogItemId} onChange={e => setForm(f => ({ ...f, catalogItemId: e.target.value }))} className="a360-input">
                <option value="">Select from approved catalog...</option>
                {activeCatalog.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="a360-label">QUANTITY</label>
              <input type="number" min="1" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} className="a360-input" />
            </div>
          </div>
          <div>
            <label className="a360-label">NOTES</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={3} className="a360-input" placeholder="Optional context for this request" />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => navigate('/po')} className="a360-btn-secondary">Cancel</button>
            <button type="button" onClick={handleApiSubmit} disabled={!canSubmitApi || apiSubmitted} className="a360-btn-primary">
              {apiSubmitted ? 'Submitted…' : 'Submit PO to Asset360'}
            </button>
          </div>
        </div>
      )}

      {/* ── PDF tab ── */}
      {activeTab === 'pdf' && (
        <div className="a360-card p-6 space-y-4">

          {/* Step 1: Upload */}
          {pdfStep === 'upload' && (
            <>
              <div>
                <h2 className="text-base font-semibold text-slate-900">Upload PO PDF</h2>
                <p className="text-sm text-brand-600 mt-1">
                  Upload the customer's PDF purchase order. Asset360 will extract the PO details automatically.
                </p>
              </div>
              <div>
                <label className="a360-label">PO PDF DOCUMENT</label>
                <div className="flex items-center gap-3 mt-1">
                  <button type="button" onClick={() => fileRef.current?.click()}
                    className="px-4 py-2 rounded-md border border-slate-300 bg-white text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors">
                    Upload PDF
                  </button>
                  <span className="text-sm text-slate-400">No file chosen</span>
                </div>
                <input ref={fileRef} type="file" accept="application/pdf" className="hidden" onChange={handleFile} />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => navigate('/po')} className="a360-btn-secondary">Cancel</button>
                <button type="button" disabled className="a360-btn-primary opacity-50 cursor-not-allowed">Submit PO</button>
              </div>
            </>
          )}

          {/* Step 2: Extracting */}
          {pdfStep === 'extracting' && (
            <div className="flex flex-col items-center justify-center py-10 gap-4">
              <svg className="w-8 h-8 text-brand-600 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
              </svg>
              <div className="text-center">
                <p className="font-semibold text-slate-800">Extracting PO details…</p>
                <p className="text-sm text-slate-500 mt-1">Reading <span className="font-medium">{fileName}</span></p>
              </div>
            </div>
          )}

          {/* Step 3: Review */}
          {pdfStep === 'review' && (
            <>
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-base font-semibold text-slate-900">Review Extracted Details</h2>
                  <p className="text-sm text-slate-500 mt-0.5">
                    From <span className="font-medium text-slate-700">{fileName}</span> — verify and correct before submitting.
                  </p>
                </div>
                <button type="button" onClick={resetPdf} className="text-xs text-brand-600 hover:underline mt-0.5">
                  ← Upload different file
                </button>
              </div>

              {/* Banner */}
              {extractError ? (
                <div className="flex gap-2 items-start bg-amber-50 border border-amber-200 rounded-md p-3 text-sm text-amber-800">
                  <svg className="w-4 h-4 mt-0.5 shrink-0" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
                  </svg>
                  <span>{extractError}</span>
                </div>
              ) : (
                <div className="flex gap-2 items-center bg-green-50 border border-green-200 rounded-md px-3 py-2 text-sm text-green-800">
                  <svg className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                  PO details extracted successfully. Please review before submitting.
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="a360-label">CLIENT NAME <span className="text-red-500">*</span></label>
                  <input value={extracted.clientName} onChange={e => setExtracted(x => ({ ...x, clientName: e.target.value }))} className="a360-input" placeholder="e.g. Meridian Financial Group" />
                </div>
                <div>
                  <label className="a360-label">CLIENT PO NUMBER <span className="text-red-500">*</span></label>
                  <input value={extracted.poNumber} onChange={e => setExtracted(x => ({ ...x, poNumber: e.target.value }))} className="a360-input" placeholder="e.g. MFG-PO-88301" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="a360-label">
                    CATALOG ITEM <span className="text-red-500">*</span>
                    {extracted.rawItemDescription && !extracted.catalogItemId && (
                      <span className="ml-1 text-amber-600 font-normal normal-case text-xs">
                        — PDF: "{extracted.rawItemDescription}"
                      </span>
                    )}
                  </label>
                  <select
                    value={extracted.catalogItemId}
                    onChange={e => setExtracted(x => ({ ...x, catalogItemId: e.target.value }))}
                    className={`a360-input ${!extracted.catalogItemId ? 'border-amber-400 ring-1 ring-amber-300' : ''}`}
                  >
                    <option value="">Select from approved catalog...</option>
                    {activeCatalog.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                  {extracted.rawItemDescription && extracted.catalogItemId && (
                    <p className="text-xs text-slate-400 mt-1">PDF: "{extracted.rawItemDescription}"</p>
                  )}
                </div>
                <div>
                  <label className="a360-label">QUANTITY <span className="text-red-500">*</span></label>
                  <input type="number" min="1" value={extracted.quantity} onChange={e => setExtracted(x => ({ ...x, quantity: e.target.value }))} className="a360-input" />
                </div>
              </div>

              <div>
                <label className="a360-label">UNIT COST (USD)</label>
                <input
                  type="number" min="0" step="0.01"
                  value={extracted.unitCost}
                  onChange={e => setExtracted(x => ({ ...x, unitCost: e.target.value }))}
                  className="a360-input" placeholder="Leave blank to use catalog list price"
                />
                {!extracted.unitCost && extracted.catalogItemId && (
                  <p className="text-xs text-slate-400 mt-1">
                    Defaults to catalog list price: ${activeCatalog.find(c => c.id === extracted.catalogItemId)?.clientListPrice?.toLocaleString() ?? '—'}
                  </p>
                )}
              </div>

              <div>
                <label className="a360-label">NOTES</label>
                <textarea value={extracted.notes} onChange={e => setExtracted(x => ({ ...x, notes: e.target.value }))} rows={2} className="a360-input" placeholder="Optional context for this request" />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => navigate('/po')} className="a360-btn-secondary">Cancel</button>
                <button type="button" onClick={handlePdfSubmit} disabled={!canSubmitPdf || pdfSubmitted} className="a360-btn-primary">
                  {pdfSubmitted ? 'Submitted…' : 'Submit PO'}
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
