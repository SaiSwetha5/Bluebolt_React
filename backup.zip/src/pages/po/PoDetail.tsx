import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';
import AuditLogPanel from '../../components/ui/AuditLogPanel';

export default function PoDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { purchaseOrders, purchaseRequisitions, vendorOrders, catalog, approvePO, rejectPO, auditFor } = useData();

  const [rejectModal, setRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  const po = purchaseOrders.find(p => p.id === id);
  if (!po) return <div className="text-slate-500 p-8">Purchase order not found.</div>;

  const item = catalog.find(c => c.id === po.catalogItemId);
  const prs = purchaseRequisitions.filter(pr => pr.poId === po.id);
  const vos = vendorOrders.filter(vo => vo.poId === po.id);
  const audit = auditFor(po.id);

  // Safe numeric display helpers
  const qty = Number.isFinite(po.quantity) ? po.quantity : 0;
  const cost = Number.isFinite(po.unitCost) ? po.unitCost : 0;
  const totalValue = qty * cost;

  // Resolved catalog name — never show raw ID
  const itemName = item?.name ?? (po.catalogItemId ? `Unknown item (${po.catalogItemId})` : '—');

  return (
    <div className="space-y-5 max-w-5xl">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <button onClick={() => navigate('/po')} className="text-sm text-brand-600 hover:underline mb-2 flex items-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
            Back to PO List
          </button>
          <h1 className="text-2xl font-bold text-slate-900">{po.poNumber}</h1>
          <p className="text-slate-500 text-sm">{po.clientName} · {po.id}</p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <StatusBadge status={po.status} />
          {po.status === 'PENDING_APPROVAL' && (
            <>
              <button onClick={() => approvePO(po.id, 'A. Subramanian (Cognizant)')} className="a360-btn-primary">Approve</button>
              <button onClick={() => setRejectModal(true)} className="a360-btn-danger">Reject</button>
            </>
          )}
          {po.status === 'APPROVED' && !prs.length && (
            <button onClick={() => navigate(`/procurement/pr/create/${po.id}`)} className="a360-btn-primary">Create Requisition</button>
          )}
        </div>
      </div>

      {/* Details card */}
      <div className="a360-card p-5 grid grid-cols-2 md:grid-cols-3 gap-4">
        <Field label="PO Number" value={po.poNumber} />
        <Field label="Request ID" value={po.requestId ?? '—'} />
        <Field label="Client" value={po.clientName} />
        <Field label="Source" value={po.source} />

        {/* Catalog item — full span when name is long */}
        <div className="col-span-2 md:col-span-1">
          <div className="a360-label">Catalog Item</div>
          <div className="text-sm text-slate-900">{itemName}</div>
          {/* Show if item is unrecognised */}
          {!item && po.catalogItemId && (
            <div className="text-xs text-amber-600 mt-0.5">⚠ Item not found in current catalog</div>
          )}
        </div>

        <Field label="Quantity" value={qty.toLocaleString()} />
        <Field label="Unit Cost" value={cost > 0 ? `$${cost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'} />
        <Field label="Total Value" value={totalValue > 0 ? `$${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'} />
        <Field label="Status" value={<StatusBadge status={po.status} />} />
        <Field label="Submitted" value={new Date(po.submittedAt).toLocaleString()} />
        {po.acknowledgedAt && <Field label="Acknowledged" value={new Date(po.acknowledgedAt).toLocaleString()} />}
        {po.approvedAt && <Field label="Approved" value={new Date(po.approvedAt).toLocaleString()} />}
        {po.approvedBy && <Field label="Approved By" value={po.approvedBy} />}
        {po.rejectedReason && <Field label="Rejection Reason" value={po.rejectedReason} />}
        {po.notes && <Field label="Notes" value={po.notes} />}
        {po.fileName && (
          <Field
            label="Source Document"
            value={
              <span className="flex items-center gap-1 text-brand-600">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M7 21h10a2 2 0 002-2V9l-5-5H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
                {po.fileName}
              </span>
            }
          />
        )}
      </div>

      {/* Requisitions */}
      {prs.length > 0 && (
        <div className="a360-card overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 font-semibold text-slate-800">Purchase Requisitions</div>
          <table className="w-full">
            <thead>
              <tr>
                <th className="a360-th">PR ID</th>
                <th className="a360-th">Status</th>
                <th className="a360-th">Requested Qty</th>
                <th className="a360-th">Balance Qty</th>
                <th className="a360-th">Estimated Cost</th>
              </tr>
            </thead>
            <tbody>
              {prs.map(pr => (
                <tr key={pr.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => navigate(`/procurement/pr/${pr.id}`)}>
                  <td className="a360-td font-mono text-xs text-brand-600">{pr.id}</td>
                  <td className="a360-td"><StatusBadge status={pr.status} /></td>
                  <td className="a360-td">{pr.requestedQty}</td>
                  <td className="a360-td">{pr.balanceQty}</td>
                  <td className="a360-td">${pr.estimatedTotalCost.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Vendor orders */}
      {vos.length > 0 && (
        <div className="a360-card overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 font-semibold text-slate-800">Vendor Orders</div>
          <table className="w-full">
            <thead>
              <tr>
                <th className="a360-th">Cognizant PO</th>
                <th className="a360-th">Vendor</th>
                <th className="a360-th">Qty</th>
                <th className="a360-th">Status</th>
                <th className="a360-th">ETA</th>
              </tr>
            </thead>
            <tbody>
              {vos.map(vo => (
                <tr key={vo.id} className="hover:bg-slate-50">
                  <td className="a360-td font-mono text-xs">{vo.cognizantPoNumber}</td>
                  <td className="a360-td">{vo.vendor}</td>
                  <td className="a360-td">{vo.quantity}</td>
                  <td className="a360-td"><StatusBadge status={vo.status} /></td>
                  <td className="a360-td text-xs">{vo.eta ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Audit */}
      <div className="a360-card p-5">
        <h3 className="font-semibold text-slate-800 mb-3">Audit Trail</h3>
        <AuditLogPanel entries={audit} />
      </div>

      {/* Reject modal */}
      {rejectModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-md">
            <h3 className="font-bold text-slate-900 mb-3">Reject Purchase Order</h3>
            <label className="a360-label">Reason</label>
            <textarea
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
              rows={3} className="a360-input mb-4"
              placeholder="Enter rejection reason…"
            />
            <div className="flex gap-2 justify-end">
              <button onClick={() => setRejectModal(false)} className="a360-btn-secondary">Cancel</button>
              <button
                onClick={() => { rejectPO(po.id, 'A. Subramanian', rejectReason); setRejectModal(false); }}
                className="a360-btn-danger"
                disabled={!rejectReason.trim()}
              >
                Reject
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <div className="a360-label">{label}</div>
      <div className="text-sm text-slate-900">{value}</div>
    </div>
  );
}
