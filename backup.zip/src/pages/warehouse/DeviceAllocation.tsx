import { useState } from 'react';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';

export default function DeviceAllocation() {
  const { assets, assignAsset, retireAsset } = useData();
  const [selectedAsset, setSelectedAsset] = useState('');
  const [assignForm, setAssignForm] = useState({ user: '', location: '' });
  const [filter, setFilter] = useState<'ALL' | 'IN_STOCK' | 'DEPLOYED'>('IN_STOCK');

  const filtered = assets.filter(a => filter === 'ALL' || a.lifecycleStatus === filter);
  const asset = assets.find(a => a.assetId === selectedAsset);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Device Allocation</h1>
        <p className="text-slate-500 text-sm">Assign in-stock assets to employees or retire them.</p>
      </div>

      <div className="flex gap-1 bg-slate-100 rounded-lg p-1 w-fit">
        {(['ALL', 'IN_STOCK', 'DEPLOYED'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${filter === f ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600 hover:text-slate-900'}`}>
            {f.replace('_', ' ')}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 a360-card overflow-auto max-h-[600px]">
          <table className="w-full">
            <thead>
              <tr>
                <th className="a360-th">Asset ID</th>
                <th className="a360-th">Serial</th>
                <th className="a360-th">Model</th>
                <th className="a360-th">Status</th>
                <th className="a360-th">Assigned To</th>
                <th className="a360-th">Location</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(a => (
                <tr key={a.assetId} className={`cursor-pointer hover:bg-slate-50 ${selectedAsset === a.assetId ? 'bg-brand-50' : ''}`} onClick={() => setSelectedAsset(a.assetId)}>
                  <td className="a360-td font-mono text-xs text-brand-600">{a.assetId}</td>
                  <td className="a360-td font-mono text-xs">{a.serialNumber}</td>
                  <td className="a360-td text-xs truncate max-w-[160px]">{a.model}</td>
                  <td className="a360-td"><StatusBadge status={a.lifecycleStatus} /></td>
                  <td className="a360-td text-xs">{a.assignedUser ?? '—'}</td>
                  <td className="a360-td text-xs">{a.location}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {asset && (
          <div className="a360-card p-5 space-y-4">
            <h3 className="font-semibold text-slate-800">Asset Actions</h3>
            <div className="space-y-1 text-sm">
              <p><span className="text-slate-500">ID:</span> {asset.assetId}</p>
              <p><span className="text-slate-500">Serial:</span> {asset.serialNumber}</p>
              <p><span className="text-slate-500">Model:</span> {asset.model}</p>
              <p><span className="text-slate-500">Status:</span> <StatusBadge status={asset.lifecycleStatus} /></p>
            </div>
            {asset.lifecycleStatus === 'IN_STOCK' && (
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <p className="text-sm font-semibold text-slate-700">Assign to Employee</p>
                <input value={assignForm.user} onChange={e => setAssignForm(f => ({ ...f, user: e.target.value }))} className="a360-input" placeholder="Employee name or ID" />
                <input value={assignForm.location} onChange={e => setAssignForm(f => ({ ...f, location: e.target.value }))} className="a360-input" placeholder="Location / office" />
                <button onClick={() => { assignAsset(asset.assetId, assignForm.user, assignForm.location); setSelectedAsset(''); }} disabled={!assignForm.user || !assignForm.location} className="a360-btn-primary w-full justify-center">Assign</button>
              </div>
            )}
            {asset.lifecycleStatus !== 'RETIRED' && (
              <button onClick={() => { retireAsset(asset.assetId); setSelectedAsset(''); }} className="a360-btn-danger w-full justify-center mt-2">Retire Asset</button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
