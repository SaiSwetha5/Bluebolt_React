import { useState, useRef } from 'react';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';

export default function GoodsReceipt() {
  const { vendorOrders, purchaseOrders, goodsReceipts, createGoodsReceipt } = useData();
  const fileRef = useRef<HTMLInputElement>(null);

  const [selectedVo, setSelectedVo] = useState('');
  const [form, setForm] = useState({ qtyReceived: '', receivedBy: 'Warehouse Ops - S. Iyer', condition: 'Good' as 'Good' | 'Damaged' | 'Partial', notes: '' });
  const [podFileName, setPodFileName] = useState('');
  const [podDataUrl, setPodDataUrl] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const deliveredVos = vendorOrders.filter(vo => vo.status === 'DELIVERED' && !goodsReceipts.some(g => g.vendorOrderId === vo.id));
  const getPoNumber = (poId: string) => purchaseOrders.find(p => p.id === poId)?.poNumber ?? poId;
  const vo = vendorOrders.find(v => v.id === selectedVo);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPodFileName(file.name);
    const reader = new FileReader();
    reader.onload = ev => setPodDataUrl(ev.target?.result as string);
    reader.readAsDataURL(file);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!vo) return;
    createGoodsReceipt({
      vendorOrderId: vo.id,
      poId: vo.poId,
      quantityReceived: parseInt(form.qtyReceived, 10),
      quantityExpected: vo.quantity,
      receivedBy: form.receivedBy,
      condition: form.condition,
      notes: form.notes || undefined,
      podFileName: podFileName || undefined,
      podDataUrl: podDataUrl || undefined,
    });
    setSubmitted(true);
    setTimeout(() => { setSelectedVo(''); setSubmitted(false); setForm({ qtyReceived: '', receivedBy: 'Warehouse Ops - S. Iyer', condition: 'Good', notes: '' }); setPodFileName(''); setPodDataUrl(''); }, 1000);
  }

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Goods Receipt</h1>
        <p className="text-slate-500 text-sm">Record delivery and capture proof of delivery (POD).</p>
      </div>

      {/* Existing GRNs */}
      <div className="a360-card overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-100 font-semibold text-slate-800">Recent GRNs</div>
        <table className="w-full">
          <thead><tr><th className="a360-th">GRN ID</th><th className="a360-th">Vendor Order</th><th className="a360-th">Qty Received</th><th className="a360-th">Condition</th><th className="a360-th">Received</th></tr></thead>
          <tbody>
            {goodsReceipts.length === 0 && <tr><td colSpan={5} className="a360-td text-center text-slate-400">No GRNs yet.</td></tr>}
            {goodsReceipts.map(g => (
              <tr key={g.id}>
                <td className="a360-td font-mono text-xs">{g.id}</td>
                <td className="a360-td font-mono text-xs">{g.vendorOrderId}</td>
                <td className="a360-td">{g.quantityReceived}/{g.quantityExpected}</td>
                <td className="a360-td"><StatusBadge status={g.condition.toUpperCase()} /></td>
                <td className="a360-td text-xs">{new Date(g.receivedAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* New GRN form */}
      {deliveredVos.length > 0 && (
        <div className="a360-card p-6 space-y-4">
          <h3 className="font-semibold text-slate-800">New Goods Receipt</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="a360-label">Select Delivered Vendor Order *</label>
              <select value={selectedVo} onChange={e => { setSelectedVo(e.target.value); const v = vendorOrders.find(x => x.id === e.target.value); setForm(f => ({ ...f, qtyReceived: v?.quantity.toString() ?? '' })); }} className="a360-input" required>
                <option value="">— Select —</option>
                {deliveredVos.map(v => <option key={v.id} value={v.id}>{v.cognizantPoNumber} — {v.vendor} — {v.quantity} units ({getPoNumber(v.poId)})</option>)}
              </select>
            </div>
            {vo && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="a360-label">Quantity Received *</label>
                    <input type="number" min="1" max={vo.quantity} value={form.qtyReceived} onChange={e => setForm(f => ({ ...f, qtyReceived: e.target.value }))} className="a360-input" required />
                  </div>
                  <div>
                    <label className="a360-label">Received By *</label>
                    <input value={form.receivedBy} onChange={e => setForm(f => ({ ...f, receivedBy: e.target.value }))} className="a360-input" required />
                  </div>
                </div>
                <div>
                  <label className="a360-label">Condition *</label>
                  <select value={form.condition} onChange={e => setForm(f => ({ ...f, condition: e.target.value as typeof form.condition }))} className="a360-input">
                    <option>Good</option><option>Damaged</option><option>Partial</option>
                  </select>
                </div>
                <div>
                  <label className="a360-label">POD File (optional)</label>
                  <div onClick={() => fileRef.current?.click()} className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center cursor-pointer hover:border-brand-400 text-sm text-slate-500">
                    {podFileName ? podFileName : 'Click to upload proof of delivery'}
                  </div>
                  <input ref={fileRef} type="file" accept="application/pdf,image/*" className="hidden" onChange={handleFile} />
                </div>
                <div>
                  <label className="a360-label">Notes</label>
                  <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} className="a360-input" />
                </div>
                <button type="submit" disabled={submitted} className="a360-btn-primary">
                  {submitted ? 'Submitted!' : 'Submit GRN'}
                </button>
              </>
            )}
          </form>
        </div>
      )}
    </div>
  );
}
