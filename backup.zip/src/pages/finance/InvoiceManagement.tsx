import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';

export default function InvoiceManagement() {
  const { invoices, vendorOrders, goodsReceipts, submitInvoice, approveInvoicePayment } = useData();
  const navigate = useNavigate();
  const [showNewForm, setShowNewForm] = useState(false);
  const [form, setForm] = useState({ vendor: 'HP' as 'HP' | 'Dell' | 'Lenovo', vendorOrderId: '', grnId: '', poId: '', amount: '', invoiceDate: '', dueDate: '' });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    submitInvoice({ vendor: form.vendor, vendorOrderId: form.vendorOrderId, grnId: form.grnId || undefined, poId: form.poId, amount: parseFloat(form.amount), currency: 'USD', invoiceDate: form.invoiceDate, dueDate: form.dueDate });
    setShowNewForm(false);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Invoice Management</h1>
          <p className="text-slate-500 text-sm">{invoices.length} invoices · {invoices.filter(i => i.status === 'EXCEPTION').length} exceptions</p>
        </div>
        <button onClick={() => setShowNewForm(s => !s)} className="a360-btn-primary">+ New Invoice</button>
      </div>

      {showNewForm && (
        <div className="a360-card p-6">
          <h3 className="font-semibold text-slate-800 mb-4">Submit Vendor Invoice</h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
            <div>
              <label className="a360-label">Vendor</label>
              <select value={form.vendor} onChange={e => setForm(f => ({ ...f, vendor: e.target.value as typeof form.vendor }))} className="a360-input">
                <option>HP</option><option>Dell</option><option>Lenovo</option>
              </select>
            </div>
            <div>
              <label className="a360-label">Vendor Order ID</label>
              <select value={form.vendorOrderId} onChange={e => { const vo = vendorOrders.find(v => v.id === e.target.value); setForm(f => ({ ...f, vendorOrderId: e.target.value, poId: vo?.poId ?? f.poId, grnId: goodsReceipts.find(g => g.vendorOrderId === e.target.value)?.id ?? '' })); }} className="a360-input">
                <option value="">— Select —</option>
                {vendorOrders.filter(v => v.status === 'DELIVERED').map(v => <option key={v.id} value={v.id}>{v.cognizantPoNumber}</option>)}
              </select>
            </div>
            <div>
              <label className="a360-label">Amount (USD)</label>
              <input type="number" min="0" step="0.01" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} className="a360-input" required />
            </div>
            <div>
              <label className="a360-label">Invoice Date</label>
              <input type="date" value={form.invoiceDate} onChange={e => setForm(f => ({ ...f, invoiceDate: e.target.value }))} className="a360-input" required />
            </div>
            <div>
              <label className="a360-label">Due Date</label>
              <input type="date" value={form.dueDate} onChange={e => setForm(f => ({ ...f, dueDate: e.target.value }))} className="a360-input" required />
            </div>
            <div className="flex items-end gap-2">
              <button type="submit" className="a360-btn-primary">Submit</button>
              <button type="button" onClick={() => setShowNewForm(false)} className="a360-btn-secondary">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="a360-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr>
              <th className="a360-th">Invoice ID</th>
              <th className="a360-th">Vendor</th>
              <th className="a360-th">Amount</th>
              <th className="a360-th">Invoice Date</th>
              <th className="a360-th">Due Date</th>
              <th className="a360-th">3-Way Match</th>
              <th className="a360-th">Status</th>
              <th className="a360-th">Actions</th>
            </tr>
          </thead>
          <tbody>
            {invoices.length === 0 && <tr><td colSpan={8} className="a360-td text-center text-slate-400 py-8">No invoices.</td></tr>}
            {invoices.map(inv => (
              <tr key={inv.id} className="hover:bg-slate-50">
                <td className="a360-td font-mono text-xs">{inv.id}</td>
                <td className="a360-td font-semibold">{inv.vendor}</td>
                <td className="a360-td font-semibold">${inv.amount.toLocaleString()}</td>
                <td className="a360-td text-xs">{inv.invoiceDate}</td>
                <td className="a360-td text-xs">{inv.dueDate}</td>
                <td className="a360-td">
                  {inv.matchResult ? (
                    <div className="flex gap-1">
                      {['poMatch', 'podMatch', 'grnMatch'].map(k => (
                        <span key={k} className={`w-5 h-5 flex items-center justify-center rounded text-xs font-bold ${(inv.matchResult as any)[k] ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                          {k === 'poMatch' ? 'P' : k === 'podMatch' ? 'D' : 'G'}
                        </span>
                      ))}
                    </div>
                  ) : '—'}
                </td>
                <td className="a360-td"><StatusBadge status={inv.status} /></td>
                <td className="a360-td">
                  {inv.status === 'MATCHED' && (
                    <button onClick={() => approveInvoicePayment(inv.id, 'Finance - R. Nair')} className="text-xs text-brand-600 hover:underline">Approve Payment</button>
                  )}
                  {inv.status === 'APPROVED_FOR_PAYMENT' && (
                    <button onClick={() => navigate('/finance/ap')} className="text-xs text-brand-600 hover:underline">Create Lease</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
