import { useState } from 'react';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';
import type { VendorName } from '../../types/models';

export default function ApProcessing() {
  const { invoices, leaseSchedules, createLeaseSchedule, markInvoicePaid } = useData();
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  const [leaseForm, setLeaseForm] = useState({ termMonths: '36', monthlyPayment: '', startDate: '', endDate: '' });

  const approvedInvoices = invoices.filter(i => i.status === 'APPROVED_FOR_PAYMENT');
  const selectedInvoice = invoices.find(i => i.id === selectedInvoiceId);

  function handleCreateLease(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedInvoice) return;
    createLeaseSchedule({
      vendor: selectedInvoice.vendor as VendorName,
      invoiceId: selectedInvoice.id,
      termMonths: parseInt(leaseForm.termMonths, 10),
      monthlyPayment: parseFloat(leaseForm.monthlyPayment),
      startDate: leaseForm.startDate,
      endDate: leaseForm.endDate,
    });
    setSelectedInvoiceId('');
  }

  return (
    <div className="space-y-5 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">AP Processing</h1>
        <p className="text-slate-500 text-sm">Finalize invoice payments and create lease schedules.</p>
      </div>

      {/* Approved invoices awaiting lease */}
      {approvedInvoices.length > 0 && (
        <div className="a360-card p-5 space-y-4">
          <h3 className="font-semibold text-slate-800">Create Lease Schedule</h3>
          <div>
            <label className="a360-label">Select Invoice</label>
            <select value={selectedInvoiceId} onChange={e => setSelectedInvoiceId(e.target.value)} className="a360-input">
              <option value="">— Select approved invoice —</option>
              {approvedInvoices.map(i => <option key={i.id} value={i.id}>{i.id} — {i.vendor} — ${i.amount.toLocaleString()}</option>)}
            </select>
          </div>
          {selectedInvoice && (
            <form onSubmit={handleCreateLease} className="grid grid-cols-2 gap-4">
              <div>
                <label className="a360-label">Term (months)</label>
                <input type="number" min="1" value={leaseForm.termMonths} onChange={e => setLeaseForm(f => ({ ...f, termMonths: e.target.value }))} className="a360-input" required />
              </div>
              <div>
                <label className="a360-label">Monthly Payment (USD)</label>
                <input type="number" min="0" step="0.01" value={leaseForm.monthlyPayment} onChange={e => setLeaseForm(f => ({ ...f, monthlyPayment: e.target.value }))} className="a360-input" required />
              </div>
              <div>
                <label className="a360-label">Lease Start Date</label>
                <input type="date" value={leaseForm.startDate} onChange={e => setLeaseForm(f => ({ ...f, startDate: e.target.value }))} className="a360-input" required />
              </div>
              <div>
                <label className="a360-label">Lease End Date</label>
                <input type="date" value={leaseForm.endDate} onChange={e => setLeaseForm(f => ({ ...f, endDate: e.target.value }))} className="a360-input" required />
              </div>
              <div className="col-span-2">
                <button type="submit" className="a360-btn-primary">Create Lease Schedule</button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Lease schedules table */}
      <div className="a360-card overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-100 font-semibold text-slate-800">Lease Schedules</div>
        <table className="w-full">
          <thead>
            <tr>
              <th className="a360-th">Lease ID</th>
              <th className="a360-th">Vendor</th>
              <th className="a360-th">Invoice</th>
              <th className="a360-th">Term</th>
              <th className="a360-th">Monthly</th>
              <th className="a360-th">Start</th>
              <th className="a360-th">End</th>
              <th className="a360-th">Status</th>
            </tr>
          </thead>
          <tbody>
            {leaseSchedules.length === 0 && <tr><td colSpan={8} className="a360-td text-center text-slate-400 py-6">No lease schedules.</td></tr>}
            {leaseSchedules.map(ls => (
              <tr key={ls.id} className="hover:bg-slate-50">
                <td className="a360-td font-mono text-xs">{ls.id}</td>
                <td className="a360-td">{ls.vendor}</td>
                <td className="a360-td font-mono text-xs">{ls.invoiceId}</td>
                <td className="a360-td">{ls.termMonths} mo</td>
                <td className="a360-td font-semibold">${ls.monthlyPayment.toLocaleString()}</td>
                <td className="a360-td text-xs">{ls.startDate}</td>
                <td className="a360-td text-xs">{ls.endDate}</td>
                <td className="a360-td"><StatusBadge status={ls.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Invoices summary */}
      <div className="a360-card overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-100 font-semibold text-slate-800">All Invoices</div>
        <table className="w-full">
          <thead><tr><th className="a360-th">Invoice ID</th><th className="a360-th">Vendor</th><th className="a360-th">Amount</th><th className="a360-th">Status</th><th className="a360-th">Lease</th><th className="a360-th">Actions</th></tr></thead>
          <tbody>
            {invoices.map(inv => (
              <tr key={inv.id} className="hover:bg-slate-50">
                <td className="a360-td font-mono text-xs">{inv.id}</td>
                <td className="a360-td">{inv.vendor}</td>
                <td className="a360-td font-semibold">${inv.amount.toLocaleString()}</td>
                <td className="a360-td"><StatusBadge status={inv.status} /></td>
                <td className="a360-td font-mono text-xs">{inv.leaseScheduleId ?? '—'}</td>
                <td className="a360-td">
                  {inv.status === 'APPROVED_FOR_PAYMENT' && !inv.leaseScheduleId && (
                    <button onClick={() => setSelectedInvoiceId(inv.id)} className="text-xs text-brand-600 hover:underline">Create Lease</button>
                  )}
                  {inv.status === 'APPROVED_FOR_PAYMENT' && inv.leaseScheduleId && (
                    <button onClick={() => markInvoicePaid(inv.id)} className="text-xs text-emerald-600 hover:underline">Mark Paid</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
