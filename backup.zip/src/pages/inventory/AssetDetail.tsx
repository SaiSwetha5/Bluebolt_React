import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';
import AuditLogPanel from '../../components/ui/AuditLogPanel';

export default function AssetDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { assets, catalog, purchaseOrders, vendorOrders, goodsReceipts, auditFor, retireAsset } = useData();

  const asset = assets.find(a => a.assetId === id);
  if (!asset) return <div className="text-slate-500 p-8">Asset not found.</div>;

  const item = catalog.find(c => c.id === asset.catalogItemId);
  const po = purchaseOrders.find(p => p.id === asset.poId);
  const vo = vendorOrders.find(v => v.id === asset.vendorOrderId);
  const grn = goodsReceipts.find(g => g.id === asset.grnId);
  const audit = auditFor(asset.assetId);

  return (
    <div className="space-y-5 max-w-4xl">
      <div className="flex items-start justify-between gap-4">
        <div>
          <button onClick={() => navigate('/inventory/assets')} className="text-sm text-brand-600 hover:underline mb-2 flex items-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
            Back to Assets
          </button>
          <h1 className="text-2xl font-bold text-slate-900">{asset.assetId}</h1>
          <p className="text-slate-500 text-sm">{asset.serialNumber} · {asset.vendor} {asset.model}</p>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={asset.lifecycleStatus} />
          {asset.lifecycleStatus !== 'RETIRED' && (
            <button onClick={() => retireAsset(asset.assetId)} className="a360-btn-danger">Retire</button>
          )}
        </div>
      </div>

      <div className="a360-card p-5 grid grid-cols-2 md:grid-cols-3 gap-4">
        <Field label="Asset ID" value={asset.assetId} />
        <Field label="Serial Number" value={asset.serialNumber} />
        <Field label="Device Type" value={asset.deviceType} />
        <Field label="Vendor" value={asset.vendor} />
        <Field label="Model" value={asset.model} />
        <Field label="Catalog Item" value={item?.name ?? asset.catalogItemId} />
        <Field label="Cost" value={`$${asset.cost.toLocaleString()}`} />
        <Field label="Location" value={asset.location} />
        <Field label="Assigned To" value={asset.assignedUser ?? '—'} />
        <Field label="Lifecycle Status" value={<StatusBadge status={asset.lifecycleStatus} />} />
        <Field label="Shipment Status" value={asset.shipmentStatus} />
        {asset.leaseStartDate && <Field label="Lease Start" value={asset.leaseStartDate} />}
        {asset.leaseEndDate && <Field label="Lease End" value={asset.leaseEndDate} />}
        {asset.contract && <Field label="Contract / Lease" value={asset.contract} />}
        {po && <Field label="Customer PO" value={<button onClick={() => navigate(`/po/${po.id}`)} className="text-brand-600 hover:underline">{po.poNumber}</button>} />}
        {vo && <Field label="Vendor Order" value={vo.cognizantPoNumber} />}
        {grn && <Field label="GRN" value={grn.id} />}
      </div>

      <div className="a360-card p-5">
        <h3 className="font-semibold text-slate-800 mb-3">Audit Trail</h3>
        <AuditLogPanel entries={audit} />
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <div className="a360-label">{label}</div>
      <div className="text-sm text-slate-900">{value}</div>
    </div>
  );
}
