import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';
import type { LifecycleStatus } from '../../types/models';

const LIFECYCLE_TABS = ['ALL', 'IN_STOCK', 'DEPLOYED', 'IN_PROCUREMENT', 'IN_TRANSIT', 'IN_REPAIR', 'RETIRED'] as const;

export default function AssetList() {
  const { assets } = useData();
  const navigate = useNavigate();
  const [tab, setTab] = useState<'ALL' | LifecycleStatus>('ALL');
  const [search, setSearch] = useState('');

  const filtered = assets
    .filter(a => tab === 'ALL' || a.lifecycleStatus === tab)
    .filter(a => !search || a.serialNumber.toLowerCase().includes(search.toLowerCase()) || a.model.toLowerCase().includes(search.toLowerCase()) || a.assetId.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Asset Registry</h1>
        <p className="text-slate-500 text-sm">{assets.length} total assets</p>
      </div>

      <div className="flex flex-col gap-3">
        <div className="flex flex-wrap gap-1 bg-slate-100 rounded-lg p-1 w-fit">
          {LIFECYCLE_TABS.map(t => (
            <button key={t} onClick={() => setTab(t)} className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${tab === t ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600 hover:text-slate-900'}`}>
              {t.replace('_', ' ')}
            </button>
          ))}
        </div>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by asset ID, serial, or model…" className="a360-input max-w-sm" />
      </div>

      <div className="a360-card overflow-auto max-h-[65vh]">
        <table className="w-full">
          <thead>
            <tr>
              <th className="a360-th">Asset ID</th>
              <th className="a360-th">Serial</th>
              <th className="a360-th">Model</th>
              <th className="a360-th">Vendor</th>
              <th className="a360-th">Cost</th>
              <th className="a360-th">Location</th>
              <th className="a360-th">Assigned To</th>
              <th className="a360-th">Status</th>
              <th className="a360-th">Lease End</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={9} className="a360-td text-center text-slate-400 py-8">No assets found.</td></tr>}
            {filtered.map(a => (
              <tr key={a.assetId} className="hover:bg-slate-50 cursor-pointer" onClick={() => navigate(`/inventory/assets/${a.assetId}`)}>
                <td className="a360-td font-mono text-xs text-brand-600">{a.assetId}</td>
                <td className="a360-td font-mono text-xs">{a.serialNumber}</td>
                <td className="a360-td text-xs truncate max-w-[180px]">{a.model}</td>
                <td className="a360-td">{a.vendor}</td>
                <td className="a360-td">${a.cost.toLocaleString()}</td>
                <td className="a360-td text-xs">{a.location}</td>
                <td className="a360-td text-xs">{a.assignedUser ?? '—'}</td>
                <td className="a360-td"><StatusBadge status={a.lifecycleStatus} /></td>
                <td className="a360-td text-xs">{a.leaseEndDate ?? '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
