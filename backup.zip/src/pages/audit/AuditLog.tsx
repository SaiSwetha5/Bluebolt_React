import { useState, useMemo } from 'react';
import { useData } from '../../store/DataContext';
import type { AuditLogEntry } from '../../types/models';

export default function AuditLog() {
  const { auditLog } = useData();
  const [search, setSearch] = useState('');
  const [entityFilter, setEntityFilter] = useState('');
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 50;

  const filtered = useMemo(() => auditLog.filter(e => {
    if (entityFilter && e.entityType !== entityFilter) return false;
    if (search && !e.entityId.toLowerCase().includes(search.toLowerCase()) && !e.details.toLowerCase().includes(search.toLowerCase()) && !e.actor.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  }), [auditLog, search, entityFilter]);

  const total = filtered.length;
  const pages = Math.ceil(total / PAGE_SIZE);
  const shown = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const ENTITY_TYPES: AuditLogEntry['entityType'][] = ['PO', 'PR', 'VendorOrder', 'GRN', 'Invoice', 'Lease', 'Asset', 'Catalog'];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Audit Log</h1>
        <p className="text-slate-500 text-sm">{total.toLocaleString()} entries</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} placeholder="Search ID, actor, details…" className="a360-input max-w-xs" />
        <select value={entityFilter} onChange={e => { setEntityFilter(e.target.value); setPage(1); }} className="a360-input max-w-[200px]">
          <option value="">All entity types</option>
          {ENTITY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <div className="text-sm text-slate-500 flex items-center">{total} result{total !== 1 ? 's' : ''}</div>
      </div>

      <div className="a360-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr>
              <th className="a360-th">Timestamp</th>
              <th className="a360-th">Action</th>
              <th className="a360-th">Entity</th>
              <th className="a360-th">Entity ID</th>
              <th className="a360-th">Actor</th>
              <th className="a360-th">Details</th>
            </tr>
          </thead>
          <tbody>
            {shown.length === 0 && <tr><td colSpan={6} className="a360-td text-center text-slate-400 py-8">No audit entries found.</td></tr>}
            {shown.map(e => (
              <tr key={e.id} className="hover:bg-slate-50">
                <td className="a360-td font-mono text-xs whitespace-nowrap">{new Date(e.timestamp).toLocaleString()}</td>
                <td className="a360-td text-xs font-medium">{e.action.replace(/_/g, ' ')}</td>
                <td className="a360-td">
                  <span className="text-xs bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">{e.entityType}</span>
                </td>
                <td className="a360-td font-mono text-xs text-brand-600">{e.entityId.length > 40 ? e.entityId.slice(0, 40) + '…' : e.entityId}</td>
                <td className="a360-td text-xs">{e.actor}</td>
                <td className="a360-td text-xs text-slate-600 max-w-xs">{e.details}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {pages > 1 && (
        <div className="flex items-center gap-2">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="a360-btn-secondary py-1.5 px-3">← Prev</button>
          <span className="text-sm text-slate-600">Page {page} of {pages}</span>
          <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages} className="a360-btn-secondary py-1.5 px-3">Next →</button>
        </div>
      )}
    </div>
  );
}
