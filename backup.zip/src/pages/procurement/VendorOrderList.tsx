import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';
import Timeline from '../../components/ui/Timeline';

export default function VendorOrderList() {
  const { vendorOrders, purchaseOrders, submitVendorOrder, advanceVendorOrderStatus, addShipmentEvent } = useData();
  const navigate = useNavigate();
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const getPoNumber = (poId: string) => purchaseOrders.find(p => p.id === poId)?.poNumber ?? poId;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Vendor Orders</h1>
          <p className="text-slate-500 text-sm">{vendorOrders.length} total orders</p>
        </div>
        <button onClick={() => navigate('/procurement/vendor-orders/create/new')} className="a360-btn-primary">+ New Vendor Order</button>
      </div>

      <div className="a360-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr>
              <th className="a360-th">Cognizant PO</th>
              <th className="a360-th">Vendor</th>
              <th className="a360-th">SKU</th>
              <th className="a360-th">Customer PO</th>
              <th className="a360-th">Qty</th>
              <th className="a360-th">Unit Cost</th>
              <th className="a360-th">Channel</th>
              <th className="a360-th">Status</th>
              <th className="a360-th">ETA</th>
              <th className="a360-th"></th>
            </tr>
          </thead>
          <tbody>
            {vendorOrders.length === 0 && (
              <tr><td colSpan={10} className="a360-td text-center text-slate-400 py-8">No vendor orders.</td></tr>
            )}
            {vendorOrders.map(vo => (
              <>
                <tr key={vo.id} className="hover:bg-slate-50">
                  <td className="a360-td font-mono text-xs">{vo.cognizantPoNumber}</td>
                  <td className="a360-td font-semibold">{vo.vendor}</td>
                  <td className="a360-td font-mono text-xs">{vo.vendorSku}</td>
                  <td className="a360-td text-xs">{getPoNumber(vo.poId)}</td>
                  <td className="a360-td">{vo.quantity}</td>
                  <td className="a360-td">${vo.unitCost.toLocaleString()}</td>
                  <td className="a360-td text-xs">{vo.channel}</td>
                  <td className="a360-td">
                    <div className="flex items-center gap-2">
                      <StatusBadge status={vo.status} />
                      {vo.status === 'DRAFT' && <button onClick={() => submitVendorOrder(vo.id)} className="text-xs text-brand-600 hover:underline">Submit</button>}
                      {vo.status === 'SUBMITTED' && <button onClick={() => advanceVendorOrderStatus(vo.id, 'CONFIRMED', { confirmedAt: new Date().toISOString(), eta: '2026-09-15' })} className="text-xs text-brand-600 hover:underline">Confirm</button>}
                      {vo.status === 'CONFIRMED' && <button onClick={() => addShipmentEvent(vo.id, 'IN_TRANSIT', 'Origin Hub')} className="text-xs text-brand-600 hover:underline">Ship</button>}
                      {vo.status === 'SHIPPED' && <button onClick={() => addShipmentEvent(vo.id, 'DELIVERED', 'Cognizant Warehouse')} className="text-xs text-brand-600 hover:underline">Deliver</button>}
                    </div>
                  </td>
                  <td className="a360-td text-xs">{vo.eta ?? '—'}</td>
                  <td className="a360-td">
                    <button onClick={() => setExpandedId(expandedId === vo.id ? null : vo.id)} className="text-xs text-slate-500 hover:text-slate-800">
                      {expandedId === vo.id ? '▲' : '▼'}
                    </button>
                  </td>
                </tr>
                {expandedId === vo.id && (
                  <tr key={`${vo.id}-exp`}>
                    <td colSpan={10} className="px-6 pb-4 bg-slate-50">
                      <div className="pt-3">
                        <p className="text-xs font-semibold text-slate-500 uppercase mb-2">Shipment History</p>
                        <Timeline events={vo.shipmentHistory} />
                      </div>
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
