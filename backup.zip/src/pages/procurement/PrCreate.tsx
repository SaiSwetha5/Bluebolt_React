import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import type { VendorName } from '../../types/models';
import { VENDOR_NAMES } from '../../types/models';

export default function PrCreate() {
  const { poId } = useParams<{ poId: string }>();
  const navigate = useNavigate();
  const { purchaseOrders, catalog, createPurchaseRequisition, availableWarehouseStock, onOrderQuantity } = useData();

  const po = purchaseOrders.find(p => p.id === poId);
  const item = po ? catalog.find(c => c.id === po.catalogItemId) : null;
  const inStock = po ? availableWarehouseStock(po.catalogItemId) : 0;
  const onOrder = po ? onOrderQuantity(po.catalogItemId) : 0;

  const [form, setForm] = useState({
    preferredVendor: '' as VendorName | '',
    estimatedUnitCost: item?.clientListPrice?.toString() ?? '',
    costCenter: 'CC-APAC-IT-01',
    justification: '',
    requestedBy: 'S. Krishnamurthy',
  });

  if (!po) return <div className="text-slate-500 p-8">Purchase order not found.</div>;

  const balance = Math.max(po.quantity - inStock - onOrder, 0);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const pr = createPurchaseRequisition({
      poId: po!.id,
      requestedQty: po!.quantity,
      preferredVendor: form.preferredVendor as VendorName || undefined,
      estimatedUnitCost: parseFloat(form.estimatedUnitCost),
      costCenter: form.costCenter,
      justification: form.justification,
      requestedBy: form.requestedBy,
    });
    navigate(`/procurement/pr/${pr.id}`);
  }

  return (
    <div className="max-w-2xl space-y-5">
      <div>
        <button onClick={() => navigate(`/po/${po.id}`)} className="text-sm text-brand-600 hover:underline mb-2 flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
          Back to PO
        </button>
        <h1 className="text-2xl font-bold text-slate-900">Create Purchase Requisition</h1>
        <p className="text-slate-500 text-sm">For {po.poNumber} — {po.clientName}</p>
      </div>

      {/* Stock summary */}
      <div className="a360-card p-4 grid grid-cols-3 gap-4 text-center">
        <div><div className="text-2xl font-bold text-slate-800">{po.quantity}</div><div className="text-xs text-slate-500">Requested Qty</div></div>
        <div><div className="text-2xl font-bold text-emerald-600">{inStock}</div><div className="text-xs text-slate-500">In Stock</div></div>
        <div><div className="text-2xl font-bold text-brand-600">{balance}</div><div className="text-xs text-slate-500">Balance to Procure</div></div>
      </div>

      <div className="a360-card p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="a360-label">Catalog Item</label>
              <p className="text-sm text-slate-900">{item?.name ?? po.catalogItemId}</p>
            </div>
            <div>
              <label className="a360-label">Preferred Vendor</label>
              <select value={form.preferredVendor} onChange={e => setForm(f => ({ ...f, preferredVendor: e.target.value as VendorName }))} className="a360-input">
                <option value="">— Any vendor —</option>
                {VENDOR_NAMES.map(v => <option key={v} value={v}>{v}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="a360-label">Estimated Unit Cost (USD) *</label>
              <input type="number" min="0" step="0.01" value={form.estimatedUnitCost} onChange={e => setForm(f => ({ ...f, estimatedUnitCost: e.target.value }))} className="a360-input" required />
            </div>
            <div>
              <label className="a360-label">Cost Center *</label>
              <input value={form.costCenter} onChange={e => setForm(f => ({ ...f, costCenter: e.target.value }))} className="a360-input" required />
            </div>
          </div>

          <div>
            <label className="a360-label">Justification *</label>
            <textarea value={form.justification} onChange={e => setForm(f => ({ ...f, justification: e.target.value }))} rows={3} className="a360-input" required />
          </div>

          <div>
            <label className="a360-label">Requested By *</label>
            <input value={form.requestedBy} onChange={e => setForm(f => ({ ...f, requestedBy: e.target.value }))} className="a360-input" required />
          </div>

          <div className="flex gap-2 pt-2">
            <button type="submit" className="a360-btn-primary">Create Requisition</button>
            <button type="button" onClick={() => navigate(`/po/${po.id}`)} className="a360-btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
