import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import type { VendorName } from '../../types/models';
import { VENDOR_NAMES } from '../../types/models';

export default function VendorOrderCreate() {
  const { poId } = useParams<{ poId: string }>();
  const navigate = useNavigate();
  const { purchaseOrders, purchaseRequisitions, catalog, createVendorOrder, submitVendorOrder, markPrConverted } = useData();

  const po = purchaseOrders.find(p => p.id === poId);
  const pr = purchaseRequisitions.find(p => p.poId === poId && (p.status === 'APPROVED' || p.status === 'DRAFT'));
  const item = po ? catalog.find(c => c.id === po.catalogItemId) : null;
  const vendorMappings = item?.vendorMappings ?? [];

  const [form, setForm] = useState({
    vendor: 'HP' as VendorName,
    vendorSku: vendorMappings[0]?.currentGenSku ?? '',
    channel: 'Webshop Portal' as 'Webshop Portal' | 'Integrated Procurement API' | 'EDI',
    quantity: po?.quantity?.toString() ?? '',
    unitCost: vendorMappings[0]?.unitCost?.toString() ?? '',
    destination: 'Cognizant Warehouse' as 'Cognizant Warehouse' | 'Client Office',
    cognizantPoOverride: '',
  });

  if (!po) return <div className="text-slate-500 p-8">Purchase order not found.</div>;

  function handleVendorChange(v: VendorName) {
    const mapping = vendorMappings.find(m => m.vendor === v);
    setForm(f => ({ ...f, vendor: v, vendorSku: mapping?.currentGenSku ?? '', unitCost: mapping?.unitCost?.toString() ?? f.unitCost }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const vo = createVendorOrder({
      poId: po!.id,
      requestId: po!.requestId ?? '',
      prId: pr?.id,
      vendor: form.vendor,
      vendorSku: form.vendorSku,
      channel: form.channel,
      quantity: parseInt(form.quantity, 10),
      unitCost: parseFloat(form.unitCost),
      destination: form.destination,
      catalogItemId: po!.catalogItemId,
      cognizantPoOverride: form.cognizantPoOverride || undefined,
    });
    submitVendorOrder(vo.id);
    if (pr) markPrConverted(pr.id);
    navigate('/procurement/vendor-orders');
  }

  return (
    <div className="max-w-2xl space-y-5">
      <div>
        <button onClick={() => navigate(-1)} className="text-sm text-brand-600 hover:underline mb-2 flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
          Back
        </button>
        <h1 className="text-2xl font-bold text-slate-900">Create Vendor Order</h1>
        <p className="text-slate-500 text-sm">For {po.poNumber} — {po.clientName}</p>
      </div>

      <div className="a360-card p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="a360-label">Vendor *</label>
              <select value={form.vendor} onChange={e => handleVendorChange(e.target.value as VendorName)} className="a360-input">
                {VENDOR_NAMES.map(v => <option key={v} value={v}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="a360-label">Vendor SKU *</label>
              <input value={form.vendorSku} onChange={e => setForm(f => ({ ...f, vendorSku: e.target.value }))} className="a360-input" required />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="a360-label">Channel *</label>
              <select value={form.channel} onChange={e => setForm(f => ({ ...f, channel: e.target.value as typeof form.channel }))} className="a360-input">
                <option>Webshop Portal</option>
                <option>Integrated Procurement API</option>
                <option>EDI</option>
              </select>
            </div>
            <div>
              <label className="a360-label">Destination *</label>
              <select value={form.destination} onChange={e => setForm(f => ({ ...f, destination: e.target.value as typeof form.destination }))} className="a360-input">
                <option>Cognizant Warehouse</option>
                <option>Client Office</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="a360-label">Quantity *</label>
              <input type="number" min="1" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} className="a360-input" required />
            </div>
            <div>
              <label className="a360-label">Unit Cost (USD) *</label>
              <input type="number" min="0" step="0.01" value={form.unitCost} onChange={e => setForm(f => ({ ...f, unitCost: e.target.value }))} className="a360-input" required />
            </div>
          </div>

          <div>
            <label className="a360-label">Cognizant PO Override (optional)</label>
            <input value={form.cognizantPoOverride} onChange={e => setForm(f => ({ ...f, cognizantPoOverride: e.target.value }))} className="a360-input" placeholder="Auto-generated if blank" />
          </div>

          <div className="flex gap-2 pt-2">
            <button type="submit" className="a360-btn-primary">Create &amp; Submit Order</button>
            <button type="button" onClick={() => navigate(-1)} className="a360-btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
