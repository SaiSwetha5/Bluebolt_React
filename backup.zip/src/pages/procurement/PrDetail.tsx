import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';
import AuditLogPanel from '../../components/ui/AuditLogPanel';

export default function PrDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { purchaseRequisitions, purchaseOrders, catalog, approvePr, rejectPr, emailPrForApproval, submitPrForApproval, auditFor } = useData();

  const [approverEmail, setApproverEmail] = useState('a.subramanian@cognizant.com');
  const [rejectModal, setRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  const pr = purchaseRequisitions.find(p => p.id === id);
  if (!pr) return <div className="text-slate-500 p-8">Requisition not found.</div>;

  const po = purchaseOrders.find(p => p.id === pr.poId);
  const item = catalog.find(c => c.id === pr.catalogItemId);
  const audit = auditFor(pr.id);

  function sendForApproval() {
    emailPrForApproval(pr!.id, approverEmail);
    submitPrForApproval(pr!.id);
  }

  return (
    <div className="space-y-5 max-w-5xl">
      <div className="flex items-start justify-between gap-4">
        <div>
          <button onClick={() => navigate('/procurement/pr')} className="text-sm text-brand-600 hover:underline mb-2 flex items-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
            Back to Requisitions
          </button>
          <h1 className="text-2xl font-bold text-slate-900">{pr.id}</h1>
          <p className="text-slate-500 text-sm">Requested by {pr.requestedBy}</p>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={pr.status} />
          {pr.status === 'PENDING_APPROVAL' && (
            <>
              <button onClick={() => approvePr(pr.id, 'A. Subramanian (Cognizant)')} className="a360-btn-primary">Approve PR</button>
              <button onClick={() => setRejectModal(true)} className="a360-btn-danger">Reject</button>
            </>
          )}
          {pr.status === 'APPROVED' && (
            <button onClick={() => navigate(`/procurement/vendor-orders/create/${pr.poId}`)} className="a360-btn-primary">Create Vendor Order</button>
          )}
        </div>
      </div>

      <div className="a360-card p-5 grid grid-cols-2 md:grid-cols-3 gap-4">
        <Field label="PR ID" value={pr.id} />
        <Field label="Request ID" value={pr.requestId} />
        <Field label="Customer PO" value={<button onClick={() => navigate(`/po/${pr.poId}`)} className="text-brand-600 hover:underline">{pr.poId}</button>} />
        <Field label="PO Number" value={po?.poNumber ?? '—'} />
        <Field label="Client" value={po?.clientName ?? '—'} />
        <Field label="Catalog Item" value={item?.name ?? pr.catalogItemId} />
        <Field label="Requested Qty" value={pr.requestedQty} />
        <Field label="In Stock" value={pr.inStockQty} />
        <Field label="On Order" value={pr.onOrderQty} />
        <Field label="Balance to Procure" value={<span className="font-bold text-brand-600">{pr.balanceQty}</span>} />
        <Field label="Preferred Vendor" value={pr.preferredVendor ?? '—'} />
        <Field label="Est. Unit Cost" value={`$${pr.estimatedUnitCost.toLocaleString()}`} />
        <Field label="Est. Total Cost" value={`$${pr.estimatedTotalCost.toLocaleString()}`} />
        <Field label="Cost Center" value={pr.costCenter} />
        <Field label="Justification" value={pr.justification} />
        {pr.approvedBy && <Field label="Approved By" value={pr.approvedBy} />}
        {pr.approvedAt && <Field label="Approved At" value={new Date(pr.approvedAt).toLocaleString()} />}
        {pr.rejectedReason && <Field label="Rejection Reason" value={pr.rejectedReason} />}
      </div>

      {/* Email for approval */}
      {pr.status === 'DRAFT' && (
        <div className="a360-card p-5 space-y-3">
          <h3 className="font-semibold text-slate-800">Send for Approval</h3>
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="a360-label">Approver Email</label>
              <input value={approverEmail} onChange={e => setApproverEmail(e.target.value)} className="a360-input" />
            </div>
            <div className="flex items-end">
              <button onClick={sendForApproval} className="a360-btn-primary">Send for Approval</button>
            </div>
          </div>
          {pr.emailedTo && <p className="text-xs text-emerald-600">Approval email sent to {pr.emailedTo}</p>}
        </div>
      )}

      <div className="a360-card p-5">
        <h3 className="font-semibold text-slate-800 mb-3">Audit Trail</h3>
        <AuditLogPanel entries={audit} />
      </div>

      {rejectModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-md">
            <h3 className="font-bold text-slate-900 mb-3">Reject Requisition</h3>
            <label className="a360-label">Reason</label>
            <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} rows={3} className="a360-input mb-4" placeholder="Enter rejection reason…" />
            <div className="flex gap-2 justify-end">
              <button onClick={() => setRejectModal(false)} className="a360-btn-secondary">Cancel</button>
              <button onClick={() => { rejectPr(pr.id, 'A. Subramanian', rejectReason); setRejectModal(false); }} className="a360-btn-danger" disabled={!rejectReason.trim()}>Reject</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <div className="a360-label">{label}</div>
      <div className="text-sm text-slate-900">{value}</div>
    </div>
  );
}
