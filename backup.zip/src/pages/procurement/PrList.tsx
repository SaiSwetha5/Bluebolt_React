import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../store/DataContext';
import StatusBadge from '../../components/ui/StatusBadge';
import type { PrStatus } from '../../types/models';

const TABS: { label: string; filter: PrStatus | 'ALL' }[] = [
  { label: 'All', filter: 'ALL' },
  { label: 'Draft', filter: 'DRAFT' },
  { label: 'Pending Approval', filter: 'PENDING_APPROVAL' },
  { label: 'Approved', filter: 'APPROVED' },
  { label: 'Rejected', filter: 'REJECTED' },
  { label: 'Converted', filter: 'CONVERTED' },
];

export default function PrList() {
  const { purchaseRequisitions, purchaseOrders } = useData();
  const navigate = useNavigate();
  const [tab, setTab] = useState<PrStatus | 'ALL'>('ALL');

  const filtered = purchaseRequisitions.filter(pr => tab === 'ALL' || pr.status === tab);
  const getPoNumber = (poId: string) => purchaseOrders.find(p => p.id === poId)?.poNumber ?? poId;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Purchase Requisitions</h1>
          <p className="text-slate-500 text-sm">{purchaseRequisitions.length} total requisitions</p>
        </div>
      </div>

      <div className="flex gap-1 bg-slate-100 rounded-lg p-1 w-fit">
        {TABS.map(t => (
          <button key={t.filter} onClick={() => setTab(t.filter)}
            className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${tab === t.filter ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600 hover:text-slate-900'}`}>
            {t.label}
          </button>
        ))}
      </div>

      <div className="a360-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr>
              <th className="a360-th">PR ID</th>
              <th className="a360-th">Customer PO</th>
              <th className="a360-th">Requested By</th>
              <th className="a360-th">Qty</th>
              <th className="a360-th">Balance Qty</th>
              <th className="a360-th">Est. Cost</th>
              <th className="a360-th">Vendor</th>
              <th className="a360-th">Status</th>
              <th className="a360-th">Requested</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={9} className="a360-td text-center text-slate-400 py-8">No requisitions found.</td></tr>
            )}
            {filtered.map(pr => (
              <tr key={pr.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => navigate(`/procurement/pr/${pr.id}`)}>
                <td className="a360-td font-mono text-xs text-brand-600">{pr.id}</td>
                <td className="a360-td text-xs">{getPoNumber(pr.poId)}</td>
                <td className="a360-td">{pr.requestedBy}</td>
                <td className="a360-td">{pr.requestedQty}</td>
                <td className="a360-td font-semibold">{pr.balanceQty}</td>
                <td className="a360-td">${pr.estimatedTotalCost.toLocaleString()}</td>
                <td className="a360-td">{pr.preferredVendor ?? '—'}</td>
                <td className="a360-td"><StatusBadge status={pr.status} /></td>
                <td className="a360-td text-xs">{new Date(pr.requestedAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
