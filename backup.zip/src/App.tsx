import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { DataProvider } from './store/DataContext';
import Shell from './components/layout/Shell';
import Dashboard from './pages/Dashboard';
import PoList from './pages/po/PoList';
import PoDetail from './pages/po/PoDetail';
import PoImport from './pages/po/PoImport';
import PrList from './pages/procurement/PrList';
import PrDetail from './pages/procurement/PrDetail';
import PrCreate from './pages/procurement/PrCreate';
import VendorOrderList from './pages/procurement/VendorOrderList';
import VendorOrderCreate from './pages/procurement/VendorOrderCreate';
import ShipmentTracking from './pages/warehouse/ShipmentTracking';
import GoodsReceipt from './pages/warehouse/GoodsReceipt';
import DeviceAllocation from './pages/warehouse/DeviceAllocation';
import VendorPoList from './pages/grn/VendorPoList';
import GrnEntry from './pages/grn/GrnEntry';
import GrnApproval from './pages/grn/GrnApproval';
import GrnList from './pages/grn/GrnList';
import InvoiceManagement from './pages/finance/InvoiceManagement';
import ApProcessing from './pages/finance/ApProcessing';
import AssetList from './pages/inventory/AssetList';
import AssetDetail from './pages/inventory/AssetDetail';
import CatalogList from './pages/catalog/CatalogList';
import CatalogDetail from './pages/catalog/CatalogDetail';
import AuditLog from './pages/audit/AuditLog';

export default function App() {
  return (
    <DataProvider>
      <BrowserRouter>
        <Shell>
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />

            {/* PO Management */}
            <Route path="/po" element={<PoList />} />
            <Route path="/po/:id" element={<PoDetail />} />
            <Route path="/po/import" element={<PoImport />} />

            {/* Procurement */}
            <Route path="/procurement/pr" element={<PrList />} />
            <Route path="/procurement/pr/:id" element={<PrDetail />} />
            <Route path="/procurement/pr/create/:poId" element={<PrCreate />} />
            <Route path="/procurement/vendor-orders" element={<VendorOrderList />} />
            <Route path="/procurement/vendor-orders/create/:poId" element={<VendorOrderCreate />} />

            {/* Warehouse */}
            <Route path="/warehouse/shipment" element={<ShipmentTracking />} />
            <Route path="/warehouse/grn" element={<GoodsReceipt />} />
            <Route path="/warehouse/allocation" element={<DeviceAllocation />} />

            {/* Vendor PO → GRN */}
            <Route path="/procurement/vendor-po" element={<VendorPoList />} />
            <Route path="/procurement/vendor-po/:id/grn" element={<GrnEntry />} />
            <Route path="/procurement/grn-approval" element={<GrnApproval />} />
            <Route path="/procurement/grn-list" element={<GrnList />} />

            {/* Finance */}
            <Route path="/finance/invoices" element={<InvoiceManagement />} />
            <Route path="/finance/ap" element={<ApProcessing />} />

            {/* Inventory */}
            <Route path="/inventory/assets" element={<AssetList />} />
            <Route path="/inventory/assets/:id" element={<AssetDetail />} />

            {/* Catalog */}
            <Route path="/catalog" element={<CatalogList />} />
            <Route path="/catalog/:id" element={<CatalogDetail />} />

            {/* Audit */}
            <Route path="/audit" element={<AuditLog />} />
          </Routes>
        </Shell>
      </BrowserRouter>
    </DataProvider>
  );
}
