import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useData } from '../../store/DataContext';

interface NavItem { label: string; path: string; icon: string; }
interface NavGroup { group: string; items: NavItem[]; }

const NAV: NavGroup[] = [
  {
    group: 'Overview',
    items: [
      { label: 'Dashboard', path: '/dashboard', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    ]
  },
  {
    group: 'PO Management',
    items: [
      { label: 'Purchase Orders', path: '/po', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
      { label: 'Import PO (PDF)', path: '/po/import', icon: 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12' },
    ]
  },
  {
    group: 'Procurement',
    items: [
      { label: 'Requisitions (PR)', path: '/procurement/pr', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
      { label: 'Vendor Orders', path: '/procurement/vendor-orders', icon: 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z' },
      { label: 'Vendor PO List', path: '/procurement/vendor-po', icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10' },
      { label: 'GRN Approval', path: '/procurement/grn-approval', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
      { label: 'GRN List', path: '/procurement/grn-list', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
    ]
  },
  {
    group: 'Warehouse',
    items: [
      { label: 'Shipment Tracking', path: '/warehouse/shipment', icon: 'M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0' },
      { label: 'Goods Receipt', path: '/warehouse/grn', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
      { label: 'Device Allocation', path: '/warehouse/allocation', icon: 'M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17H4a1 1 0 01-1-1V4a1 1 0 011-1h16a1 1 0 011 1v12a1 1 0 01-1 1h-1' },
    ]
  },
  {
    group: 'Finance',
    items: [
      { label: 'Invoice Management', path: '/finance/invoices', icon: 'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z' },
      { label: 'AP Processing', path: '/finance/ap', icon: 'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z' },
    ]
  },
  {
    group: 'Inventory',
    items: [
      { label: 'Asset Registry', path: '/inventory/assets', icon: 'M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17H4a1 1 0 01-1-1V4a1 1 0 011-1h16a1 1 0 011 1v12a1 1 0 01-1 1h-1' },
    ]
  },
  {
    group: 'Catalog',
    items: [
      { label: 'Device Catalog', path: '/catalog', icon: 'M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z' },
    ]
  },
  {
    group: 'Compliance',
    items: [
      { label: 'Audit Log', path: '/audit', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
    ]
  },
];

export default function Shell({ children }: { children: React.ReactNode }) {
  const { dashboardStats, notifications, markAllNotificationsRead } = useData();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [notifOpen, setNotifOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} flex-shrink-0 bg-brand-800 text-white flex flex-col transition-all duration-300 overflow-hidden`}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-brand-700">
          <div className="flex items-center justify-center flex-shrink-0 w-8 h-8 bg-white rounded">
            <span className="text-xs font-black text-brand-800">A3</span>
          </div>
          {sidebarOpen && (
            <div className="min-w-0">
              <div className="text-sm font-bold leading-tight">Asset360</div>
              <div className="text-xs text-brand-300">Cognizant DaaS</div>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-3 overflow-y-auto scrollbar-none">
          {NAV.map(group => (
            <div key={group.group} className="mb-2">
              {sidebarOpen && (
                <div className="px-4 py-1 text-xs font-semibold tracking-wider uppercase text-brand-300">{group.group}</div>
              )}
              {group.items.map(item => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-4 py-2 text-sm transition-colors ${isActive ? 'bg-brand-600 text-white' : 'text-brand-200 hover:bg-brand-700 hover:text-white'}`
                  }
                  title={!sidebarOpen ? item.label : undefined}
                >
                  <svg className="flex-shrink-0 w-5 h-5" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d={item.icon} />
                  </svg>
                  {sidebarOpen && <span className="truncate">{item.label}</span>}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
      </aside>

      {/* Main */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center flex-shrink-0 gap-4 px-4 py-3 bg-white border-b border-slate-200">
          <button onClick={() => setSidebarOpen(s => !s)} className="p-1.5 rounded hover:bg-slate-100 text-slate-600">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>

          <div className="flex-1" />

          {/* Notification bell */}
          <div className="relative">
            <button
              onClick={() => { setNotifOpen(o => !o); if (dashboardStats.unreadNotifications > 0) markAllNotificationsRead(); }}
              className="relative p-1.5 rounded hover:bg-slate-100 text-slate-600"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
              </svg>
              {dashboardStats.unreadNotifications > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {dashboardStats.unreadNotifications > 9 ? '9+' : dashboardStats.unreadNotifications}
                </span>
              )}
            </button>

            {notifOpen && (
              <div className="absolute right-0 z-50 mt-2 overflow-hidden bg-white border shadow-lg top-full w-96 border-slate-200 rounded-xl">
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
                  <span className="text-sm font-semibold text-slate-900">Procurement Inbox</span>
                  <button onClick={() => setNotifOpen(false)} className="text-slate-400 hover:text-slate-600">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                </div>
                <div className="overflow-y-auto divide-y max-h-80 divide-slate-100">
                  {notifications.length === 0 ? (
                    <div className="px-4 py-6 text-sm text-center text-slate-400">No notifications</div>
                  ) : notifications.slice(0, 10).map(n => (
                    <div key={n.id} className={`px-4 py-3 text-sm ${n.read ? 'text-slate-500' : 'text-slate-900 bg-blue-50'}`}>
                      <div className="font-semibold truncate">{n.subject}</div>
                      <div className="text-xs text-slate-400 mt-0.5">{new Date(n.timestamp).toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User avatar */}
          <div className="flex items-center justify-center w-8 h-8 text-xs font-bold text-white rounded-full cursor-pointer bg-brand-600" title="S. Krishnamurthy">SK</div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-6 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
