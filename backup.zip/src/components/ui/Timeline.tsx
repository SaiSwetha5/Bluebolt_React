import type { ShipmentEvent } from '../../types/models';

interface Props { events: ShipmentEvent[]; }

const STATUS_COLORS: Record<string, string> = {
  DELIVERED: 'bg-emerald-500',
  OUT_FOR_DELIVERY: 'bg-purple-500',
  IN_TRANSIT: 'bg-blue-500',
  LABEL_CREATED: 'bg-slate-400',
  PENDING: 'bg-amber-400',
  EXCEPTION: 'bg-rose-500',
};

export default function Timeline({ events }: Props) {
  if (!events.length) return <p className="text-sm text-slate-400 italic">No shipment events yet.</p>;

  return (
    <ol className="relative border-l border-slate-200 ml-3">
      {[...events].reverse().map((ev, i) => (
        <li key={i} className="mb-4 ml-6">
          <span className={`absolute -left-1.5 mt-1 w-3 h-3 rounded-full ${STATUS_COLORS[ev.status] ?? 'bg-slate-400'}`} />
          <p className="text-sm font-semibold text-slate-800">{ev.status.replace(/_/g, ' ')}</p>
          {ev.location && <p className="text-xs text-slate-500">{ev.location}</p>}
          {ev.note && <p className="text-xs text-slate-400 italic">{ev.note}</p>}
          <time className="text-xs text-slate-400">{new Date(ev.timestamp).toLocaleString()}</time>
        </li>
      ))}
    </ol>
  );
}
