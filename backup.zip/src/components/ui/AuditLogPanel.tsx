import type { AuditLogEntry } from '../../types/models';

interface Props { entries: AuditLogEntry[]; }

export default function AuditLogPanel({ entries }: Props) {
  if (!entries.length) return <p className="text-sm text-slate-400 italic">No audit events.</p>;
  return (
    <div className="space-y-2">
      {entries.map(e => (
        <div key={e.id} className="flex gap-3 text-sm">
          <div className="w-36 flex-shrink-0 text-xs text-slate-400 pt-0.5">
            {new Date(e.timestamp).toLocaleString()}
          </div>
          <div>
            <span className="font-semibold text-slate-700">{e.action.replace(/_/g, ' ')}</span>
            <span className="text-slate-400 mx-1">·</span>
            <span className="text-slate-600">{e.details}</span>
            {e.actor !== 'system' && (
              <span className="ml-1 text-xs text-slate-400">by {e.actor}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
