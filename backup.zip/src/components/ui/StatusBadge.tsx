type Color = 'green' | 'yellow' | 'red' | 'blue' | 'slate' | 'purple' | 'orange';

const COLOR_MAP: Record<string, Color> = {
  // PO
  RECEIVED: 'blue', ACKNOWLEDGED: 'yellow', PENDING_APPROVAL: 'yellow',
  APPROVED: 'green', REJECTED: 'red',
  // PR
  DRAFT: 'slate', CONVERTED: 'purple',
  // Vendor Order
  SUBMITTED: 'blue', CONFIRMED: 'blue', IN_PRODUCTION: 'blue',
  SHIPPED: 'purple', DELIVERED: 'green', CANCELLED: 'red',
  // Invoice
  MATCHED: 'green', EXCEPTION: 'red', APPROVED_FOR_PAYMENT: 'blue', PAID: 'green',
  // GRN
  PENDING_APPROVAL2: 'yellow', GOOD: 'green', DAMAGED: 'red', PARTIAL: 'orange',
  GOOD2: 'green',
  // Asset
  IN_PROCUREMENT: 'blue', IN_TRANSIT: 'purple', IN_STOCK: 'yellow',
  DEPLOYED: 'green', IN_REPAIR: 'orange', RETIRED: 'slate',
  // Shipment
  LABEL_CREATED: 'slate', IN_TRANSIT2: 'blue', OUT_FOR_DELIVERY: 'purple',
  PENDING: 'yellow', PARTIALLY_RECEIVED: 'orange', COMPLETED: 'green',
};

const STYLES: Record<Color, string> = {
  green:  'bg-emerald-50 text-emerald-700 ring-emerald-200',
  yellow: 'bg-amber-50 text-amber-700 ring-amber-200',
  red:    'bg-rose-50 text-rose-700 ring-rose-200',
  blue:   'bg-blue-50 text-blue-700 ring-blue-200',
  slate:  'bg-slate-100 text-slate-600 ring-slate-200',
  purple: 'bg-purple-50 text-purple-700 ring-purple-200',
  orange: 'bg-orange-50 text-orange-700 ring-orange-200',
};

function getColor(status: string): Color {
  return COLOR_MAP[status] ?? 'slate';
}

interface Props { status: string; className?: string; }

export default function StatusBadge({ status, className = '' }: Props) {
  const color = getColor(status);
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset ${STYLES[color]} ${className}`}>
      {status.replace(/_/g, ' ')}
    </span>
  );
}
